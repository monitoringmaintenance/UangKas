-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2026 at 01:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kas_pt`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori_transaksi`
--

CREATE TABLE `kategori_transaksi` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `jenis` enum('masuk','keluar') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori_transaksi`
--

INSERT INTO `kategori_transaksi` (`id`, `nama_kategori`, `jenis`, `created_at`) VALUES
(1, 'Setoran Modal', 'masuk', '2026-08-19 03:35:26'),
(2, 'Penjualan / Pendapatan Lain', 'masuk', '2026-08-19 03:35:26'),
(3, 'Pengembalian Dana', 'masuk', '2026-08-19 03:35:26'),
(4, 'Operasional Kantor', 'keluar', '2026-08-19 03:35:26'),
(5, 'Gaji & Tunjangan Karyawan', 'keluar', '2026-08-19 03:35:26'),
(6, 'Perlengkapan & ATK', 'keluar', '2026-08-19 03:35:26'),
(7, 'Reimburse / Pengajuan HRD', 'keluar', '2026-08-19 03:35:26');

-- --------------------------------------------------------

--
-- Table structure for table `pengajuan_dana`
--

CREATE TABLE `pengajuan_dana` (
  `id` int(11) NOT NULL,
  `tanggal_pengajuan` date NOT NULL,
  `hrd_id` int(11) NOT NULL,
  `keperluan` varchar(255) NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `status` enum('pending','disetujui','ditolak') NOT NULL DEFAULT 'pending',
  `catatan_bendahara` varchar(255) DEFAULT NULL,
  `diproses_oleh` int(11) DEFAULT NULL,
  `tanggal_diproses` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengajuan_dana`
--

INSERT INTO `pengajuan_dana` (`id`, `tanggal_pengajuan`, `hrd_id`, `keperluan`, `jumlah`, `status`, `catatan_bendahara`, `diproses_oleh`, `tanggal_diproses`, `created_at`) VALUES
(1, '2026-08-20', 4, 'biaya beli obat', 10000.00, 'disetujui', '', 3, '2026-08-20 13:54:02', '2026-08-20 06:51:36'),
(2, '2026-08-28', 4, 'buat bayar wifi', 500000.00, 'disetujui', '', 3, '2026-09-04 13:51:14', '2026-08-28 06:29:28'),
(4, '2026-09-04', 4, 'makan', 100000.00, 'ditolak', 'keungan habis', 3, '2026-09-04 13:52:42', '2026-09-04 06:52:13');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_kas`
--

CREATE TABLE `transaksi_kas` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `jenis` enum('masuk','keluar') NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `bukti` varchar(255) DEFAULT NULL,
  `pengajuan_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_kas`
--

INSERT INTO `transaksi_kas` (`id`, `tanggal`, `kategori_id`, `jenis`, `keterangan`, `jumlah`, `bukti`, `pengajuan_id`, `created_by`, `created_at`) VALUES
(1, '2026-08-20', 1, 'masuk', '-', 25000.00, NULL, NULL, 3, '2026-08-20 06:53:36'),
(2, '2026-08-20', 7, 'keluar', 'Pencairan dana pengajuan HRD: biaya beli obat', 10000.00, NULL, 1, 3, '2026-08-20 06:54:02'),
(3, '2026-09-04', 7, 'keluar', 'Pencairan dana pengajuan HRD: buat bayar wifi', 500000.00, NULL, 2, 3, '2026-09-04 06:51:14'),
(4, '2026-09-04', 1, 'masuk', 'wifi', 250000.00, NULL, NULL, 3, '2026-09-04 06:53:51'),
(5, '2026-09-25', 2, 'masuk', 'web2', 500000.00, NULL, NULL, 3, '2026-09-05 06:34:11'),
(6, '2026-09-12', 1, 'masuk', 'bayar uang kas fadlan', 9000000.00, NULL, NULL, 3, '2026-09-12 06:50:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `role` enum('admin','bendahara','hrd') NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nama_lengkap`, `role`, `status`, `created_at`, `updated_at`) VALUES
(2, 'admin', '$2y$10$yHau7f9Xj4fuSyr0cHfE9Of6gO5wJhQSgeoRdMyFE9WRByC6Fv/0K', 'Administrato', 'admin', 'aktif', '2026-08-19 03:40:59', '2026-09-18 07:22:21'),
(3, 'bendahara', '$2y$10$eUy4TGdvjeqoD4URZ60aeO8W9iCYt2Ye8Z7opgo2dnBdlbt6rQIYK', 'Bendahara', 'bendahara', 'aktif', '2026-08-19 03:40:59', '2026-09-05 06:35:14'),
(4, 'hrd', '$2y$10$FyXbTXPyo.UYUy0tps0A0Odx2JzXnDjsS1mtwbxd0ScLzCEhjHPK2', 'HRD', 'hrd', 'aktif', '2026-08-19 03:40:59', '2026-08-19 03:45:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori_transaksi`
--
ALTER TABLE `kategori_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengajuan_dana`
--
ALTER TABLE `pengajuan_dana`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrd_id` (`hrd_id`),
  ADD KEY `diproses_oleh` (`diproses_oleh`);

--
-- Indexes for table `transaksi_kas`
--
ALTER TABLE `transaksi_kas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kategori_id` (`kategori_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori_transaksi`
--
ALTER TABLE `kategori_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pengajuan_dana`
--
ALTER TABLE `pengajuan_dana`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `transaksi_kas`
--
ALTER TABLE `transaksi_kas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pengajuan_dana`
--
ALTER TABLE `pengajuan_dana`
  ADD CONSTRAINT `pengajuan_dana_ibfk_1` FOREIGN KEY (`hrd_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `pengajuan_dana_ibfk_2` FOREIGN KEY (`diproses_oleh`) REFERENCES `users` (`id`);

--
-- Constraints for table `transaksi_kas`
--
ALTER TABLE `transaksi_kas`
  ADD CONSTRAINT `transaksi_kas_ibfk_1` FOREIGN KEY (`kategori_id`) REFERENCES `kategori_transaksi` (`id`),
  ADD CONSTRAINT `transaksi_kas_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
