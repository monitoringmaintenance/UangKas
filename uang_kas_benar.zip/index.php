<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'];
if ($role == 'admin') {
    header("Location: admin/dashboard.php");
} elseif ($role == 'bendahara') {
    header("Location: bendahara/dashboard.php");
} elseif ($role == 'hrd') {
    header("Location: hrd/dashboard.php");
} else {
    header("Location: login.php");
}
exit;
