<?php
session_start();
include 'includes/koneksi.php';

if (isset($_SESSION['user_id'])) {
  $role = $_SESSION['role'];
  if ($role == 'admin')
    header("Location: admin/dashboard.php");
  elseif ($role == 'bendahara')
    header("Location: bendahara/dashboard.php");
  else
    header("Location: hrd/dashboard.php");
  exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username']);
  $password = $_POST['password'];

  if ($username == '' || $password == '') {
    $error = 'Username dan password wajib diisi.';
  } else {
    $q = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' AND status = 'aktif' LIMIT 1");
    $user = mysqli_fetch_assoc($q);

    if ($user && password_verify($password, $user['password'])) {
      session_regenerate_id(true);
      $_SESSION['user_id'] = $user['id'];
      $_SESSION['username'] = $user['username'];
      $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
      $_SESSION['role'] = $user['role'];

      if ($user['role'] == 'admin')
        header("Location: admin/dashboard.php");
      elseif ($user['role'] == 'bendahara')
        header("Location: bendahara/dashboard.php");
      else
        header("Location: hrd/dashboard.php");
      exit;
    } else {
      $error = 'Username atau password salah.';
    }
  }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | Aplikasi Kas PT</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <link rel="stylesheet" href="assets/style.css">

  <style>
    body {
      /* Diubah dari background.jpg ke background.gif */
      background: url('assets/background.gif') no-repeat center center fixed;
      background-size: cover;
      min-height: 100vh;
    }

    .login-wrapper {
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      /* Memberikan efek gelap tipis di atas GIF agar form lebih kontras dan mudah dibaca */
      background-color: rgba(0, 0, 0, 0.4);
      padding: 15px;
    }

    .login-card {
      width: 100%;
      max-width: 400px;
      border-radius: 12px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
      background-color: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(6px);
    }

    /* Menghapus background logo bawaan dari assets/style.css agar tidak tertumpuk */
    .login-icon {
      background: none !important;
      width: auto !important;
      height: auto !important;
      margin: 0 auto;
      padding: 0;
      box-shadow: none !important;
    }

    #gameLoader {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background-color: rgba(15, 23, 42, 0.9);
      backdrop-filter: blur(8px);
      display: none;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      z-index: 9999;
      color: #fff;
    }

    .game-spinner {
      width: 65px;
      height: 65px;
      border: 5px solid rgba(255, 255, 255, 0.1);
      border-top: 5px solid #0d6efd;
      border-right: 5px solid #0dcaf0;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      0% {
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
      }
    }
  </style>
</head>

<body>
  <div id="gameLoader">
    <div class="game-spinner mb-3"></div>
    <div class="fw-bold tracking-wide fs-5">MEMUAT SISTEM...</div>
    <small class="text-white-50 mt-1">Mohon tunggu <span id="countdownText">3</span> detik...</small>
  </div>

  <div class="login-wrapper">
    <div class="card login-card">
      <div class="card-body p-4">
        <div class="text-center mb-4">
          <div class="login-icon text-center mb-2">
            <img src="assets/MNC2.png" alt="Logo PT MNC" style="max-width: 110px; height: auto; object-fit: contain;">
          </div>
          <h4 class="mt-2 fw-bold" style="color:var(--text); letter-spacing:-0.3px;">
            Kas <span class="text-primary">PT MNC</span>
          </h4>
          <p class="small mb-0" style="color:var(--text-muted);">Masuk untuk mengelola kas perusahaan</p>
        </div>

        <?php if ($error): ?>
          <div class="alert alert-danger py-2 d-flex align-items-center gap-2" style="font-size:0.85rem;">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <?= $error ?>
          </div>
        <?php endif; ?>

        <form method="POST" action="login.php" id="loginForm">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-person"></i></span>
              <input type="text" name="username" class="form-control" placeholder="Masukkan username"
                value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>" required autofocus>
            </div>
          </div>
          <div class="mb-4">
            <label class="form-label">Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-lock"></i></span>
              <input type="password" name="password" id="passwordInput" class="form-control"
                placeholder="Masukkan password" required>
              <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                <i class="bi bi-eye" id="toggleIcon"></i>
              </button>
            </div>
          </div>
          <button type="submit" class="btn btn-primary w-100 py-2" id="loginBtn" style="font-size:0.9rem;">
            <i class="bi bi-box-arrow-in-right"></i> Masuk
          </button>
        </form>
      </div>
    </div>
  </div>
  <script>
    const togglePassword = document.querySelector('#togglePassword');
    const passwordInput = document.querySelector('#passwordInput');
    const toggleIcon = document.querySelector('#toggleIcon');

    togglePassword.addEventListener('click', function () {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);

      toggleIcon.classList.toggle('bi-eye');
      toggleIcon.classList.toggle('bi-eye-slash');
    });

    const loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const loader = document.getElementById('gameLoader');
      const countdownText = document.getElementById('countdownText');
      let timeLeft = 3;

      loader.style.display = 'flex';

      const timer = setInterval(() => {
        timeLeft--;
        countdownText.innerText = timeLeft;

        if (timeLeft <= 0) {
          clearInterval(timer);
          loginForm.submit();
        }
      }, 700);
    });
  </script>
</body>

</html>