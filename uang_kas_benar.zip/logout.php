<?php
session_start();
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Logout | Aplikasi Kas PT</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      background-color: #2b3240;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #ffffff;
      overflow: hidden;
    }

    .loader-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
    }

    .spinner {
      width: 60px;
      height: 60px;
      border: 5px solid rgba(255, 255, 255, 0.1);
      border-top: 5px solid #00aaff;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-bottom: 20px;
    }

    @keyframes spin {
      0% {
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
      }
    }

    .title {
      font-size: 1.25rem;
      font-weight: 700;
      letter-spacing: 1px;
      text-transform: uppercase;
      margin-bottom: 6px;
      color: #ffffff;
    }

    .subtitle {
      font-size: 0.875rem;
      color: rgba(255, 255, 255, 0.5);
      font-weight: 400;
    }
  </style>
</head>

<body>

  <div class="loader-container">
    <div class="spinner"></div>
    <div class="title">KELUAR DARI SISTEM...</div>
    <div class="subtitle">Mohon tunggu <span id="countdownText">3</span> detik...</div>
  </div>

  <script>
    let timeLeft = 3;
    const countdownText = document.getElementById('countdownText');

    const timer = setInterval(() => {
      timeLeft--;
      countdownText.innerText = timeLeft;

      if (timeLeft <= 0) {
        clearInterval(timer);
        window.location.href = "login.php";
      }
    }, 700); 
  </script>

</body>

</html>