# Aplikasi Kas PT (PHP + MySQL)

Aplikasi manajemen kas perusahaan dengan 3 role: **Admin**, **Bendahara**, dan **HRD**.

## 🧩 Fitur

- **Login & session per role**, password ter-hash aman (`password_hash`).
- **Admin**: kelola user (tambah/edit/hapus, atur role & status aktif), kelola kategori transaksi, lihat laporan kas.
- **Bendahara**: catat transaksi kas masuk/keluar, kelola kategori terkait, memproses pengajuan dana dari HRD (setujui/tolak — jika disetujui otomatis tercatat sebagai transaksi kas keluar), cetak laporan kas per periode.
- **HRD**: mengajukan permintaan dana (reimburse/kebutuhan operasional), memantau status pengajuan (menunggu/disetujui/ditolak), membatalkan pengajuan yang masih pending.
- Dashboard ringkasan saldo kas & statistik untuk tiap role.

## ⚙️ Cara Instalasi (XAMPP / Laragon)

1. Copy folder `kas_pt` ke folder `htdocs` (XAMPP) atau `www` (Laragon).
2. Buka **phpMyAdmin**, buat/klik import, lalu import file **`kas_pt.sql`** — ini akan membuat database `kas_pt` beserta tabel & kategori default.
3. Cek pengaturan koneksi di `includes/koneksi.php` (default: host `localhost`, user `root`, password kosong — sesuaikan jika perlu).
4. Jalankan **`seed.php`** sekali lewat browser, contoh:
   `http://localhost/kas_pt/seed.php`
   Ini akan membuat 3 akun default:

   | Username    | Password      | Role      |
   |-------------|---------------|-----------|
   | admin       | password123   | Admin     |
   | bendahara   | password123   | Bendahara |
   | hrd         | password123   | HRD       |

5. **Setelah seed berhasil, hapus file `seed.php`** dari server (alasan keamanan).
6. Buka `http://localhost/kas_pt/login.php` dan login sesuai role.
7. Segera ganti password default lewat menu **Admin → Kelola User**.

## 🗂️ Struktur Folder

```
kas_pt/
├── kas_pt.sql                 # skema database
├── seed.php                   # generator akun default (hapus setelah dipakai)
├── includes/koneksi.php       # koneksi mysqli + fungsi helper (format, badge, dsb.)
├── includes/header.php        # layout atas, sidebar, notifikasi
├── includes/footer.php        # layout bawah, modal, script
├── assets/style.css           # styling
├── login.php / logout.php / index.php
├── admin/                     # dashboard, kelola user, kelola kategori
├── bendahara/                 # dashboard, transaksi kas, pengajuan, laporan
└── hrd/                       # dashboard, ajukan & pantau pengajuan dana
```

## 🔐 Alur Persetujuan Dana

1. HRD mengajukan dana lewat menu **Pengajuan Dana → Ajukan Dana Baru**.
2. Bendahara melihatnya di menu **Pengajuan Dana**, lalu **Setujui** atau **Tolak**.
3. Jika **disetujui**, sistem otomatis membuat transaksi **kas keluar** dengan kategori "Reimburse / Pengajuan HRD" — saldo kas ikut berkurang otomatis.
4. HRD bisa memantau status pengajuannya kapan saja.

## 🛠️ Catatan Teknis

- PHP native (tanpa framework) + **mysqli** (fungsi prosedural `mysqli_query`, `mysqli_fetch_assoc`, dst — tanpa PDO, tanpa prepared statement), gaya kode sederhana seperti aplikasi PHP dasar pada umumnya.
- Tampilan pakai Bootstrap 5 (via CDN) — butuh koneksi internet saat dibuka di browser untuk load CSS/JS/ikon. Kalau server tidak ada akses internet, download Bootstrap & taruh lokal lalu ganti link di `includes/header.php`.
- Karena query dibangun langsung dari input (tanpa prepared statement/escaping), gunakan aplikasi ini hanya untuk pembelajaran/lingkungan lokal — bukan untuk produksi publik.
- Silakan kembangkan lebih lanjut: upload bukti transaksi (kolom `bukti` sudah disiapkan di tabel `transaksi_kas`), export laporan ke Excel/PDF, notifikasi email, dsb.
