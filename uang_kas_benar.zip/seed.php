<?php
/**
 * SEED AKUN DEFAULT
 * Jalankan file ini SEKALI lewat browser (http://localhost/kas_pt/seed.php)
 * setelah import database.sql, untuk membuat 3 akun default:
 *   - admin     / password123
 *   - bendahara / password123
 *   - hrd       / password123
 *
 * SETELAH BERHASIL DIJALANKAN, HAPUS FILE INI dari server (untuk keamanan).
 */

$allowedHosts = array('127.0.0.1', '::1', 'localhost');
$remoteAddr = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
$isLocalhost = in_array($remoteAddr, $allowedHosts);

if (!$isLocalhost) {
    http_response_code(403);
    echo '<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body>';
    echo '<h2>403 - Akses Ditolak</h2>';
    echo '<p>File ini hanya dapat diakses dari localhost.</p>';
    echo '</body></html>';
    exit;
}

include 'includes/koneksi.php';

$defaultUsers = array(
    array('username' => 'admin',     'nama' => 'Administrator', 'role' => 'admin'),
    array('username' => 'bendahara', 'nama' => 'Budi Santoso',  'role' => 'bendahara'),
    array('username' => 'hrd',       'nama' => 'Siti Aminah',   'role' => 'hrd'),
);

$passwordDefault = 'password123';
$hasil = array();

foreach ($defaultUsers as $u) {
    $cek = mysqli_query($conn, "SELECT id FROM users WHERE username = '{$u['username']}'");

    if (mysqli_fetch_assoc($cek)) {
        $hasil[] = "Akun '{$u['username']}' sudah ada, dilewati.";
        continue;
    }

    $hash = password_hash($passwordDefault, PASSWORD_DEFAULT);
    mysqli_query($conn, "INSERT INTO users (username, password, nama_lengkap, role) VALUES ('{$u['username']}', '$hash', '{$u['nama']}', '{$u['role']}')");
    $hasil[] = "Akun '{$u['username']}' berhasil dibuat.";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Seed Akun Default</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f6f9;padding:40px;}
.box{max-width:520px;margin:auto;background:#fff;padding:30px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.08);}
h2{color:#2c3e50}
li{margin-bottom:6px}
table{width:100%;border-collapse:collapse;margin-top:15px}
td,th{border:1px solid #ddd;padding:8px;text-align:left}
.warn{background:#fff3cd;border:1px solid #ffe69c;padding:12px;border-radius:6px;margin-top:20px;color:#664d03}
a.btn{display:inline-block;margin-top:20px;background:#0d6efd;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none}
</style>
</head>
<body>
<div class="box">
<h2>Proses Seed Akun Default</h2>
<ul>
<?php foreach ($hasil as $h) echo "<li>$h</li>"; ?>
</ul>
<table>
<tr><th>Username</th><th>Password</th><th>Role</th></tr>
<tr><td>admin</td><td><?= $passwordDefault ?></td><td>Admin</td></tr>
<tr><td>bendahara</td><td><?= $passwordDefault ?></td><td>Bendahara</td></tr>
<tr><td>hrd</td><td><?= $passwordDefault ?></td><td>HRD</td></tr>
</table>
<div class="warn">⚠️ Segera hapus file <b>seed.php</b> ini dari server setelah selesai, dan ganti password default lewat menu Kelola User.</div>
<a class="btn" href="login.php">Masuk ke Halaman Login →</a>
</div>
</body>
</html>
