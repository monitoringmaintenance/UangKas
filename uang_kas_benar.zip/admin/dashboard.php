<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'admin') {
  header("Location: ../login.php");
  exit;
}

$dari = isset($_GET['dari']) && $_GET['dari'] != '' ? $_GET['dari'] : date('Y-m-01');
$sampai = isset($_GET['sampai']) && $_GET['sampai'] != '' ? $_GET['sampai'] : date('Y-m-d');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dari))
  $dari = date('Y-m-01');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $sampai))
  $sampai = date('Y-m-d');

if ($dari > $sampai) {
  $temp = $dari;
  $dari = $sampai;
  $sampai = $temp;
}

$jenis = isset($_GET['jenis']) ? $_GET['jenis'] : '';
$kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

$kategoriList = mysqli_query($conn, "SELECT * FROM kategori_transaksi ORDER BY nama_kategori ASC");

$saldo = function_exists('getSaldoKas') ? getSaldoKas($conn) : array('masuk' => 0, 'keluar' => 0, 'saldo' => 0);
$saldoPeriode = function_exists('getSaldoKas') ? getSaldoKas($conn, $dari, $sampai) : array('masuk' => 0, 'keluar' => 0, 'saldo' => 0);

$resUser = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM users WHERE status = 'aktif'"));
$totalUser = $resUser ? $resUser['jml'] : 0;

$resUserAll = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM users"));
$totalUserAll = $resUserAll ? $resUserAll['jml'] : 0;

$resPending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM pengajuan_dana WHERE status = 'pending'"));
$totalPending = $resPending ? $resPending['jml'] : 0;

$resKat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM kategori_transaksi"));
$totalKategori = $resKat ? $resKat['jml'] : 0;

$resTrx = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM transaksi_kas"));
$totalTransaksi = $resTrx ? $resTrx['jml'] : 0;

$resPeng = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM pengajuan_dana"));
$totalPengajuan = $resPeng ? $resPeng['jml'] : 0;

$where = array("t.tanggal BETWEEN '$dari' AND '$sampai'");
if ($jenis !== '' && ($jenis == 'masuk' || $jenis == 'keluar')) {
  $where[] = "t.jenis = '$jenis'";
}
if ($kategori !== '' && is_numeric($kategori)) {
  $where[] = "t.kategori_id = " . (int) $kategori;
}
$whereSql = 'WHERE ' . implode(' AND ', $where);

$transaksiTerbaru = array();
$q1 = mysqli_query($conn, "
    SELECT t.*, k.nama_kategori, 
           CASE 
               WHEN u.role = 'bendahara' THEN 'Bendahara'
               ELSE COALESCE(u.nama_lengkap, u.username, 'Sistem')
           END AS pencatat
    FROM transaksi_kas t
    JOIN kategori_transaksi k ON k.id = t.kategori_id
    LEFT JOIN users u ON u.id = t.created_by
    $whereSql
    ORDER BY t.tanggal DESC, t.id DESC LIMIT 5
");
if ($q1) {
  while ($row = mysqli_fetch_assoc($q1)) {
    $transaksiTerbaru[] = $row;
  }
}

$pengajuanTerbaru = array();
$q2 = mysqli_query($conn, "
    SELECT p.*, COALESCE(u.nama_lengkap, u.username, 'HRD') AS nama_hrd
    FROM pengajuan_dana p
    LEFT JOIN users u ON u.id = p.hrd_id
    ORDER BY p.tanggal_pengajuan DESC, p.id DESC LIMIT 5
");
if ($q2) {
  while ($row = mysqli_fetch_assoc($q2)) {
    $pengajuanTerbaru[] = $row;
  }
}

$pageTitle = 'Dashboard Admin';
require '../includes/header.php';
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(15px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .stagger-children>* {
    opacity: 0;
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .stagger-children>*:nth-child(1) {
    animation-delay: 0.05s;
  }

  .stagger-children>*:nth-child(2) {
    animation-delay: 0.1s;
  }

  .stagger-children>*:nth-child(3) {
    animation-delay: 0.15s;
  }

  .stagger-children>*:nth-child(4) {
    animation-delay: 0.2s;
  }

  .btn-hover-bounce {
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .card-stat {
    border: none;
    border-radius: 14px;
    color: #fff;
    position: relative;
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .card-stat:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12) !important;
  }

  .card-stat .stat-icon {
    position: absolute;
    right: 15px;
    bottom: 12px;
    font-size: 3.2rem;
    opacity: 0.35;
    color: #ffffff;
    line-height: 1;
  }

  .card-stat .stat-label {
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.95;
  }

  .card-stat .stat-value {
    font-size: 1.5rem;
    font-weight: 800;
    margin-top: 4px;
  }

  .card-stat .stat-sub {
    font-size: 0.75rem;
    opacity: 0.9;
    margin-top: 2px;
  }

  .bg-masuk {
    background: linear-gradient(135deg, #2ecc71, #1abc9c);
  }

  .bg-keluar {
    background: linear-gradient(135deg, #e74c3c, #d63031);
  }

  .bg-saldo {
    background: linear-gradient(135deg, #3498db, #2980b9);
  }

  .bg-pending {
    background: linear-gradient(135deg, #ff7675, #e17055);
    color: #ffffff !important;
  }

  .card-modern {
    border: none;
    border-radius: 14px;
    background: #ffffff;
  }

  .card-info {
    border: none;
    border-radius: 14px;
    background: #ffffff;
    transition: all 0.2s ease;
  }

  .card-info:hover {
    transform: translateY(-2px);
  }

  .card-info-icon {
    width: 44px;
    height: 44px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
  }

  .bg-soft-primary {
    background-color: rgba(52, 152, 219, 0.12);
    color: #3498db !important;
  }

  .bg-soft-success {
    background-color: rgba(46, 204, 113, 0.12);
    color: #2ecc71 !important;
  }

  .bg-soft-info {
    background-color: rgba(26, 188, 156, 0.12);
    color: #1abc9c !important;
  }

  .bg-soft-warning {
    background-color: rgba(230, 126, 34, 0.12);
    color: #e67e22 !important;
  }

  .text-success {
    color: #2ecc71 !important;
  }

  .text-danger {
    color: #e74c3c !important;
  }

  .btn-primary {
    background-color: #3867d6;
    border-color: #3867d6;
  }

  .btn-primary:hover {
    background-color: #2b5797;
    border-color: #2b5797;
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-3 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold"><i class="bi bi-speedometer2 me-1 text-primary"></i> Dashboard Admin</h4>
  </div>
</div>

<div class="row g-3 mb-4 stagger-children">
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-masuk p-3 h-100 shadow-sm">
      <i class="bi bi-arrow-down-circle stat-icon"></i>
      <div class="stat-label small opacity-75 fw-semibold">Total Kas Masuk</div>
      <div class="stat-value fs-5 fw-bold mt-1"><?= formatRupiah($saldo['masuk']) ?></div>
      <div class="small mt-2 pt-2 border-top border-white-50 opacity-75">Periode:
        <?= formatRupiah($saldoPeriode['masuk']) ?>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-keluar p-3 h-100 shadow-sm">
      <i class="bi bi-arrow-up-circle stat-icon"></i>
      <div class="stat-label small opacity-75 fw-semibold">Total Kas Keluar</div>
      <div class="stat-value fs-5 fw-bold mt-1"><?= formatRupiah($saldo['keluar']) ?></div>
      <div class="small mt-2 pt-2 border-top border-white-50 opacity-75">Periode:
        <?= formatRupiah($saldoPeriode['keluar']) ?>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-saldo p-3 h-100 shadow-sm">
      <i class="bi bi-wallet2 stat-icon"></i>
      <div class="stat-label small opacity-75 fw-semibold">Saldo Kas</div>
      <div class="stat-value fs-4 fw-bold mt-1"><?= formatRupiah($saldo['saldo']) ?></div>
      <div class="small mt-2 opacity-75">Status Kas Aktif</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-pending p-3 h-100 shadow-sm">
      <i class="bi bi-hourglass-split stat-icon"></i>
      <div class="stat-label small opacity-75 fw-semibold">Pengajuan Pending</div>
      <div class="stat-value fs-4 fw-bold mt-1"><?= $totalPending ?></div>
      <?php if ($totalPending > 0): ?>
        <a href="pengajuan.php"
          class="text-white small mt-2 d-inline-block fw-bold text-decoration-none badge bg-white bg-opacity-25 badge-pulse">
          Proses sekarang &rarr;
        </a>
      <?php else: ?>
        <div class="small mt-2 opacity-75">Membutuhkan Persetujuan</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="row g-3 mb-4 stagger-children">
  <div class="col-md-3 col-6">
    <div class="card card-info p-3 shadow-sm h-100">
      <div class="card-info-icon bg-soft-primary text-primary mb-2"><i class="bi bi-people"></i></div>
      <h5 class="mb-0 fw-bold"><?= $totalUser ?></h5>
      <small class="text-muted">User Aktif</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-info p-3 shadow-sm h-100">
      <div class="card-info-icon bg-soft-success text-success mb-2"><i class="bi bi-tags"></i></div>
      <h5 class="mb-0 fw-bold"><?= $totalKategori ?></h5>
      <small class="text-muted">Kategori Transaksi</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-info p-3 shadow-sm h-100">
      <div class="card-info-icon bg-soft-info text-info mb-2"><i class="bi bi-receipt"></i></div>
      <h5 class="mb-0 fw-bold"><?= $totalTransaksi ?></h5>
      <small class="text-muted">Total Transaksi Kas</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-info p-3 shadow-sm h-100">
      <div class="card-info-icon bg-soft-warning text-warning mb-2"><i class="bi bi-file-earmark-text"></i></div>
      <h5 class="mb-0 fw-bold"><?= $totalPengajuan ?></h5>
      <small class="text-muted">Total Pengajuan Dana</small>
    </div>
  </div>
</div>

<div class="row g-3 animate-fade-up">
  <div class="col-lg-8">
    <div class="card card-modern p-4 mb-3 no-print shadow-sm">
      <div class="fw-bold mb-3 small text-secondary d-flex align-items-center gap-1">
        <i class="bi bi-funnel-fill text-primary"></i> Filter Transaksi & Ringkasan Kas
      </div>
      <form method="GET" action="" class="row g-3">
        <div class="col-lg-3 col-md-6">
          <label class="form-label text-muted small mb-1 fw-semibold">Dari Tanggal</label>
          <input type="date" name="dari" class="form-control form-control-sm rounded-3"
            value="<?= htmlspecialchars($dari, ENT_QUOTES, 'UTF-8') ?>">
        </div>

        <div class="col-lg-3 col-md-6">
          <label class="form-label text-muted small mb-1 fw-semibold">Sampai Tanggal</label>
          <input type="date" name="sampai" class="form-control form-control-sm rounded-3"
            value="<?= htmlspecialchars($sampai, ENT_QUOTES, 'UTF-8') ?>">
        </div>

        <div class="col-lg-3 col-md-6">
          <label class="form-label small text-muted mb-1">Jenis</label>
          <div class="position-relative">
            <select name="jenis" class="form-select form-select-sm pe-5">
              <option value="">Semua Jenis</option>
              <option value="masuk" <?= $jenis === 'masuk' ? 'selected' : '' ?>>Kas Masuk</option>
              <option value="keluar" <?= $jenis === 'keluar' ? 'selected' : '' ?>>Kas Keluar</option>
            </select>
            <span class="position-absolute top-50 end-0 translate-middle-y pe-3 text-muted"
              style="pointer-events: none;">
              <i class="bi bi-chevron-down small"></i>
            </span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <label class="form-label text-muted small mb-1 fw-semibold">Kategori</label>
          <div class="position-relative">
            <select name="kategori" class="form-select form-select-sm rounded-3 pe-5">
              <option value="">Semua Kategori</option>
              <?php if ($kategoriList): ?>
                <?php while ($kat = mysqli_fetch_assoc($kategoriList)): ?>
                  <option value="<?= $kat['id'] ?>" <?= (string) $kategori === (string) $kat['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($kat['nama_kategori'], ENT_QUOTES, 'UTF-8') ?>
                  </option>
                <?php endwhile; ?>
              <?php endif; ?>
            </select>
            <span class="position-absolute top-50 end-0 translate-middle-y pe-3 text-muted"
              style="pointer-events: none;">
              <i class="bi bi-chevron-down small"></i>
            </span>
          </div>
        </div>

        <div class="col-12 d-flex justify-content-end gap-2 pt-2 border-top">
          <a href="dashboard.php" class="btn btn-sm btn-outline-secondary px-3 btn-hover-bounce rounded-3"
            title="Reset Filter">
            <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
          </a>
          <button type="submit" class="btn btn-sm btn-primary px-4 btn-hover-bounce rounded-3 fw-semibold">
            <i class="bi bi-funnel me-1"></i> Tampilkan
          </button>
        </div>
      </form>
    </div>

    <div class="card card-modern p-3 mb-3 shadow-sm">
      <div class="d-flex justify-content-between align-items-center mb-3 border-bottom pb-2">
        <h6 class="fw-bold mb-0 text-dark">
          <i class="bi bi-clock-history text-primary me-1"></i> Transaksi Kas Terbaru
        </h6>
        <a href="transaksi.php" class="small text-decoration-none btn-hover-bounce">Lihat semua &rarr;</a>
      </div>
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr class="small text-muted">
              <th>Tanggal</th>
              <th>Kategori</th>
              <th>Keterangan</th>
              <th>Pencatat</th>
              <th class="text-end">Jumlah</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($transaksiTerbaru)): ?>
              <tr>
                <td colspan="5" class="text-center py-4">
                  <div class="empty-state">
                    <i class="bi bi-inbox fs-3 text-muted opacity-50 d-block mb-1"></i>
                    <p class="mb-0 text-muted small">Belum ada transaksi pada periode ini.</p>
                  </div>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($transaksiTerbaru as $t): ?>
                <tr>
                  <td class="text-nowrap small text-muted">
                    <i class="bi bi-calendar3 me-1"></i>
                    <?= function_exists('formatTanggalSingkat') ? formatTanggalSingkat($t['tanggal']) : date('d/m/Y', strtotime($t['tanggal'])) ?>
                  </td>
                  <td>
                    <span
                      class="badge bg-light text-dark border fw-normal"><?= htmlspecialchars($t['nama_kategori'], ENT_QUOTES, 'UTF-8') ?></span>
                  </td>
                  <td class="text-truncate" style="max-width:180px;"
                    title="<?= htmlspecialchars($t['keterangan'], ENT_QUOTES, 'UTF-8') ?>">
                    <?= htmlspecialchars($t['keterangan'], ENT_QUOTES, 'UTF-8') ?>
                  </td>
                  <td class="small text-nowrap">
                    <i class="bi bi-person me-1 text-muted"></i><?= htmlspecialchars($t['pencatat'], ENT_QUOTES, 'UTF-8') ?>
                  </td>
                  <td
                    class="text-end fw-semibold text-nowrap <?= $t['jenis'] === 'masuk' ? 'text-success' : 'text-danger' ?>">
                    <?= $t['jenis'] === 'masuk' ? '+' : '-' ?>
                    <?= function_exists('formatRupiah') ? formatRupiah($t['jumlah']) : 'Rp ' . number_format($t['jumlah'], 0, ',', '.') ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card card-modern p-3 shadow-sm">
      <div class="d-flex justify-content-between align-items-center mb-3 border-bottom pb-2">
        <i class="bi bi-file-earmark-text text-warning me-1"></i> Pengajuan Dana Terbaru
        </h6>
        <a href="pengajuan.php?status=pending" class="small text-decoration-none">Lihat semua &rarr;</a>
      </div>
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr class="small text-muted">
              <th>Tanggal</th>
              <th>HRD</th>
              <th>Keperluan</th>
              <th class="text-end">Jumlah</th>
              <th class="text-center">Status</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($pengajuanTerbaru)): ?>
              <tr>
                <td colspan="5" class="text-center py-4">
                  <div class="empty-state">
                    <i class="bi bi-inbox fs-3 text-muted opacity-50 d-block mb-1"></i>
                    <p class="mb-0 text-muted small">Belum ada pengajuan dana.</p>
                  </div>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($pengajuanTerbaru as $pj): ?>
                <tr>
                  <td class="text-nowrap small text-muted">
                    <i class="bi bi-calendar3 me-1"></i>
                    <?= function_exists('formatTanggalSingkat') ? formatTanggalSingkat($pj['tanggal_pengajuan']) : date('d/m/Y', strtotime($pj['tanggal_pengajuan'])) ?>
                  </td>
                  <td class="small text-nowrap">
                    <i
                      class="bi bi-person me-1 text-muted"></i><?= htmlspecialchars($pj['nama_hrd'], ENT_QUOTES, 'UTF-8') ?>
                  </td>
                  <td class="text-truncate" style="max-width:180px;"
                    title="<?= htmlspecialchars($pj['keperluan'], ENT_QUOTES, 'UTF-8') ?>">
                    <?= htmlspecialchars($pj['keperluan'], ENT_QUOTES, 'UTF-8') ?>
                  </td>
                  <td class="text-end fw-semibold text-nowrap">
                    <?= function_exists('formatRupiah') ? formatRupiah($pj['jumlah']) : 'Rp ' . number_format($pj['jumlah'], 0, ',', '.') ?>
                  </td>
                  <td class="text-center">
                    <?php if (function_exists('badgeStatus')): ?>
                      <?= badgeStatus($pj['status']) ?>
                    <?php else: ?>
                      <span class="badge bg-secondary"><?= htmlspecialchars($pj['status'], ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card p-3 shadow-sm border-0 rounded-3 mb-3">
      <h6 class="fw-bold mb-3">
        <i class="bi bi-pie-chart me-1 text-primary"></i> Visualisasi Kas
      </h6>
      <div style="height: 180px; position: relative;">
        <canvas id="kasChart"></canvas>
      </div>
    </div>

    <div class="card card-modern p-3 shadow-sm mb-3">
      <h6 class="fw-bold mb-3 text-dark border-bottom pb-2">
        <i class="bi bi-info-circle text-info me-1"></i> Ringkasan Pengguna Sistem
      </h6>
      <div class="small">
        <div class="d-flex justify-content-between py-2 border-bottom border-light">
          <span class="text-muted"><i class="bi bi-person-check me-1"></i> User Aktif</span>
          <span class="badge bg-success bg-opacity-10 text-success fw-semibold"><?= $totalUser ?> User</span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom border-light">
          <span class="text-muted"><i class="bi bi-people me-1"></i> Total Semua User</span>
          <span class="fw-semibold text-dark"><?= $totalUserAll ?> User</span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom border-light">
          <span class="text-muted"><i class="bi bi-receipt me-1"></i> Transaksi Kas</span>
          <span class="fw-semibold text-dark"><?= $totalTransaksi ?> Record</span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom border-light">
          <span class="text-muted"><i class="bi bi-file-earmark-text me-1"></i> Total Pengajuan</span>
          <span class="fw-semibold text-dark"><?= $totalPengajuan ?> Record</span>
        </div>
        <div class="d-flex justify-content-between pt-2">
          <span class="text-muted"><i class="bi bi-tags me-1"></i> Kategori Transaksi</span>
          <span class="fw-semibold text-dark"><?= $totalKategori ?> Kategori</span>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById('kasChart').getContext('2d');
    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Kas Masuk', 'Kas Keluar'],
        datasets: [{
          data: [<?= (float) $saldo['masuk'] ?>, <?= (float) $saldo['keluar'] ?>],
          backgroundColor: ['#38ef7d', '#e74c3c'],
          borderWidth: 0,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 12,
              font: {
                size: 11
              }
            }
          }
        },
        cutout: '70%'
      }
    });
  });
</script>

<?php require '../includes/footer.php'; ?>