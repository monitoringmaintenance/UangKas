<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'admin') {
  header("Location: ../login.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
  $id = (int) $_POST['delete_id'];
  if ($id === (int) $_SESSION['user_id']) {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Kamu tidak bisa menghapus akunmu sendiri.');
  } else {
    $hasTransaksi = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM transaksi_kas WHERE created_by = $id"))['jml'] > 0;
    $hasPengajuan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM pengajuan_dana WHERE hrd_id = $id"))['jml'] > 0;

    if ($hasTransaksi || $hasPengajuan) {
      $_SESSION['flash'] = array('type' => 'error', 'message' => 'User tidak bisa dihapus karena masih memiliki data transaksi atau pengajuan.');
    } else {
      mysqli_query($conn, "DELETE FROM users WHERE id = $id");
      $_SESSION['flash'] = array('type' => 'success', 'message' => 'User berhasil dihapus.');
    }
  }
  header('Location: users.php');
  exit;
}

$users = array();
$q = mysqli_query($conn, "SELECT * FROM users ORDER BY created_at DESC");
if ($q) {
  while ($row = mysqli_fetch_assoc($q)) {
    $users[] = $row;
  }
}

$pageTitle = 'Kelola User';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(15px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .btn-hover-bounce {
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .card-modern {
    border: none;
    border-radius: 14px;
    background: #ffffff;
  }

  .bg-soft-primary {
    background-color: rgba(52, 152, 219, 0.12) !important;
    color: #3498db !important;
  }

  .bg-soft-success {
    background-color: rgba(46, 204, 113, 0.12) !important;
    color: #2ecc71 !important;
  }

  .bg-soft-info {
    background-color: rgba(26, 188, 156, 0.12) !important;
    color: #1abc9c !important;
  }

  .bg-soft-danger {
    background-color: rgba(231, 76, 60, 0.12) !important;
    color: #e74c3c !important;
  }

  .btn-primary {
    background-color: #3867d6;
    border-color: #3867d6;
  }

  .btn-primary:hover {
    background-color: #2b5797;
    border-color: #2b5797;
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold"><i class="bi bi-people me-2 text-primary"></i> Kelola User</h4>
    <small class="text-muted">Manajemen hak akses pengguna sistem</small>
  </div>
  <a href="user_form.php" class="btn btn-primary rounded-3 btn-hover-bounce fw-semibold px-3 shadow-sm">
    <i class="bi bi-plus-lg me-1"></i> Tambah User
  </a>
</div>

<div class="card card-modern p-3 shadow-sm animate-fade-up">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr class="small text-muted">
          <th style="width: 50px;">#</th>
          <th>Nama Lengkap</th>
          <th>Username</th>
          <th>Role</th>
          <th>Status</th>
          <th>Dibuat</th>
          <th class="text-end">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($users)): ?>
          <tr>
            <td colspan="7" class="text-center py-4">
              <div class="empty-state">
                <i class="bi bi-people fs-3 text-muted opacity-50 d-block mb-1"></i>
                <p class="mb-0 text-muted small">Belum ada data user.</p>
              </div>
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($users as $i => $u): ?>
            <tr>
              <td class="small text-muted fw-bold"><?= $i + 1 ?></td>
              <td class="fw-semibold text-dark"><?= htmlspecialchars($u['nama_lengkap'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><code
                  class="px-2 py-1 rounded-2 bg-light border text-primary"><?= htmlspecialchars($u['username'], ENT_QUOTES, 'UTF-8') ?></code>
              </td>
              <td>
                <?php if ($u['role'] === 'admin'): ?>
                  <span class="badge bg-soft-primary px-2 py-1 text-capitalize"><i class="bi bi-shield-check me-1"></i>
                    <?= htmlspecialchars($u['role'], ENT_QUOTES, 'UTF-8') ?></span>
                <?php elseif ($u['role'] === 'bendahara'): ?>
                  <span class="badge bg-soft-success px-2 py-1 text-capitalize"><i class="bi bi-cash-stack me-1"></i>
                    <?= htmlspecialchars($u['role'], ENT_QUOTES, 'UTF-8') ?></span>
                <?php else: ?>
                  <span class="badge bg-soft-info px-2 py-1 text-capitalize"><i class="bi bi-person me-1"></i>
                    <?= htmlspecialchars($u['role'], ENT_QUOTES, 'UTF-8') ?></span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($u['status'] === 'aktif'): ?>
                  <span class="badge bg-soft-success px-2 py-1"><i class="bi bi-check-circle me-1"></i> Aktif</span>
                <?php else: ?>
                  <span class="badge bg-soft-danger px-2 py-1"><i class="bi bi-x-circle me-1"></i> Nonaktif</span>
                <?php endif; ?>
              </td>
              <td class="text-muted small text-nowrap">
                <i class="bi bi-calendar3 me-1"></i>
                <?= function_exists('formatTanggal') ? formatTanggal($u['created_at']) : date('d/m/Y H:i', strtotime($u['created_at'])) ?>
              </td>
              <td class="text-end">
                <a href="user_form.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary rounded-2 btn-hover-bounce"
                  title="Edit">
                  <i class="bi bi-pencil-square"></i>
                </a>
                <?php if ((int) $u['id'] !== (int) $_SESSION['user_id']): ?>
                  <form id="deleteForm<?= $u['id'] ?>" method="POST" style="display:inline;">
                    <input type="hidden" name="delete_id" value="<?= $u['id'] ?>">
                  </form>
                  <button type="button" class="btn btn-sm btn-outline-danger rounded-2 btn-hover-bounce"
                    data-confirm="Yakin ingin menghapus user ini?" data-confirm-form="deleteForm<?= $u['id'] ?>"
                    title="Hapus">
                    <i class="bi bi-trash"></i>
                  </button>
                <?php else: ?>
                  <button type="button" class="btn btn-sm btn-outline-secondary rounded-2" disabled
                    title="Tidak bisa menghapus akun sendiri">
                    <i class="bi bi-lock"></i>
                  </button>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require '../includes/footer.php'; ?>