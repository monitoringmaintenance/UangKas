<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : null;
$user = array('nama_lengkap' => '', 'username' => '', 'role' => 'hrd', 'status' => 'aktif');
$isEdit = false;
$error = '';

if ($id) {
    $found = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = $id"));
    if ($found) {
        $user = $found;
        $isEdit = true;
    } else {
        $_SESSION['flash'] = array('type' => 'error', 'message' => 'User tidak ditemukan.');
        header('Location: users.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama_lengkap']);
    $username = trim($_POST['username']);
    $role = isset($_POST['role']) ? $_POST['role'] : 'hrd';
    $status = isset($_POST['status']) ? $_POST['status'] : 'aktif';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if (!in_array($role, array('admin', 'bendahara', 'hrd'))) {
        $error = 'Role tidak valid.';
    } elseif (!in_array($status, array('aktif', 'nonaktif'))) {
        $error = 'Status tidak valid.';
    } elseif ($nama == '' || $username == '') {
        $error = 'Nama lengkap dan username wajib diisi.';
    } elseif (strlen($username) < 3) {
        $error = 'Username minimal 3 karakter.';
    } else {
        $namaEsc = mysqli_real_escape_string($conn, $nama);
        $usernameEsc = mysqli_real_escape_string($conn, $username);
        $roleEsc = mysqli_real_escape_string($conn, $role);
        $statusEsc = mysqli_real_escape_string($conn, $status);

        $idCek = $id ? $id : 0;
        $cek = mysqli_query($conn, "SELECT id FROM users WHERE username = '$usernameEsc' AND id != $idCek");

        if (mysqli_num_rows($cek) > 0) {
            $error = 'Username sudah digunakan, silakan pilih username lain.';
        } else {
            if ($isEdit) {
                if ($password !== '') {
                    if (strlen($password) < 6) {
                        $error = 'Password minimal 6 karakter.';
                    } else {
                        $hash = password_hash($password, PASSWORD_DEFAULT);
                        mysqli_query($conn, "UPDATE users SET nama_lengkap='$namaEsc', username='$usernameEsc', role='$roleEsc', status='$statusEsc', password='$hash' WHERE id=$id");
                    }
                } else {
                    mysqli_query($conn, "UPDATE users SET nama_lengkap='$namaEsc', username='$usernameEsc', role='$roleEsc', status='$statusEsc' WHERE id=$id");
                }

                if ($error === '') {
                    $_SESSION['flash'] = array('type' => 'success', 'message' => 'Data user berhasil diperbarui.');
                    header('Location: users.php');
                    exit;
                }
            } else {
                if ($password === '') {
                    $error = 'Password wajib diisi untuk user baru.';
                } elseif (strlen($password) < 6) {
                    $error = 'Password minimal 6 karakter.';
                } else {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    mysqli_query($conn, "INSERT INTO users (nama_lengkap, username, role, status, password) VALUES ('$namaEsc', '$usernameEsc', '$roleEsc', '$statusEsc', '$hash')");
                    $_SESSION['flash'] = array('type' => 'success', 'message' => 'User baru berhasil ditambahkan.');
                    header('Location: users.php');
                    exit;
                }
            }
        }
    }
    $user = array('nama_lengkap' => $nama, 'username' => $username, 'role' => $role, 'status' => $status);
}

$pageTitle = $isEdit ? 'Edit User' : 'Tambah User';
require '../includes/header.php';
?>

<style>
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(15px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fade-up {
        animation: fadeInUp 0.4s ease-out forwards;
    }

    .btn-hover-bounce {
        transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
    }

    .btn-hover-bounce:hover {
        transform: translateY(-2px);
    }

    .card-modern {
        border: none;
        border-radius: 14px;
        background: #ffffff;
    }

    .btn-primary {
        background-color: #3867d6;
        border-color: #3867d6;
    }

    .btn-primary:hover {
        background-color: #2b5797;
        border-color: #2b5797;
    }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4 animate-fade-up">
    <div>
        <h4 class="mb-0 fw-bold">
            <i class="bi bi-person-<?= $isEdit ? 'gear' : 'plus-fill' ?> me-2 text-primary"></i>
            <?= $isEdit ? 'Edit User' : 'Tambah User Baru' ?>
        </h4>
        <small
            class="text-muted"><?= $isEdit ? 'Perbarui informasi dan hak akses pengguna' : 'Buat akun pengguna baru untuk akses sistem' ?></small>
    </div>
</div>

<div class="card card-modern p-4 shadow-sm animate-fade-up" style="max-width:650px">
    <?php if ($error): ?>
        <div
            class="alert alert-danger py-2 d-flex align-items-center justify-content-center text-center gap-2 rounded-3 mb-4">
            <i class="bi bi-exclamation-triangle-fill fs-5"></i>
            <div><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        </div>
    <?php endif; ?>

    <form method="POST" id="userForm">
        <div class="mb-3">
            <label class="form-label text-muted small fw-semibold">Nama Lengkap</label>
            <input type="text" name="nama_lengkap" class="form-control rounded-3"
                value="<?= htmlspecialchars($user['nama_lengkap'], ENT_QUOTES, 'UTF-8') ?>"
                placeholder="Contoh: John Doe" required>
        </div>

        <div class="mb-3">
            <label class="form-label text-muted small fw-semibold">Username</label>
            <input type="text" name="username" class="form-control rounded-3"
                value="<?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8') ?>" placeholder="Contoh: johndoe"
                required minlength="3">
        </div>

        <div class="mb-3">
            <label class="form-label text-muted small fw-semibold">
                Password
                &nbsp;<?= $isEdit ? '<span class="text-muted fw-normal">(Opsional, kosongkan jika tidak diubah)</span>' : '<span class="text-danger">(Opsional, kosongkan jika tidak diubah)</span>' ?>
            </label>
            <div class="input-group">
                <input type="password" name="password" id="passwordInput" class="form-control rounded-start-3"
                    placeholder="<?= $isEdit ? '••••••••' : 'Masukkan password' ?>" <?= $isEdit ? '' : 'required minlength="6"' ?>>
                <button class="btn btn-outline-secondary rounded-end-3 px-3" type="button" id="togglePasswordBtn">
                    <i class="bi bi-eye" id="toggleIcon"></i>
                </button>
            </div>
        </div>

        <hr class="my-4 text-muted opacity-25">

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary rounded-3 btn-hover-bounce px-4 fw-semibold" id="submitBtn">
                <i class="bi bi-save me-1"></i> Simpan Data
            </button>
            <a href="users.php" class="btn btn-outline-secondary rounded-3 px-4">Batal</a>
        </div>
    </form>
</div>

<script>
    const togglePasswordBtn = document.getElementById('togglePasswordBtn');
    const passwordInput = document.getElementById('passwordInput');
    const toggleIcon = document.getElementById('toggleIcon');

    togglePasswordBtn.addEventListener('click', function () {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);

        toggleIcon.classList.toggle('bi-eye');
        toggleIcon.classList.toggle('bi-eye-slash');
    });

    document.getElementById('userForm').addEventListener('submit', function () {
        var btn = document.getElementById('submitBtn');
        btn.classList.add('disabled');
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Menyimpan...';
    });
</script>

<?php require '../includes/footer.php'; ?>