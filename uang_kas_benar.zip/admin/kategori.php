<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'admin') {
  header("Location: ../login.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
  $nama = trim($_POST['nama_kategori']);
  $jenis = $_POST['jenis'];

  if ($nama == '') {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Nama kategori wajib diisi.');
  } elseif ($jenis != 'masuk' && $jenis != 'keluar') {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Jenis kategori tidak valid.');
  } else {
    $namaEsc = mysqli_real_escape_string($conn, $nama);
    $jenisEsc = mysqli_real_escape_string($conn, $jenis);
    $cek = mysqli_query($conn, "SELECT id FROM kategori_transaksi WHERE nama_kategori = '$namaEsc' AND jenis = '$jenisEsc'");

    if (mysqli_num_rows($cek) > 0) {
      $_SESSION['flash'] = array('type' => 'error', 'message' => 'Kategori dengan nama dan jenis yang sama sudah ada.');
    } else {
      mysqli_query($conn, "INSERT INTO kategori_transaksi (nama_kategori, jenis) VALUES ('$namaEsc', '$jenisEsc')");
      $_SESSION['flash'] = array('type' => 'success', 'message' => 'Kategori berhasil ditambahkan.');
    }
  }
  header('Location: kategori.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['edit_id']) || isset($_POST['simpan_edit']))) {
  $id = (int) $_POST['edit_id'];
  $nama = trim($_POST['edit_nama']);
  $jenis = $_POST['edit_jenis'];

  if ($nama == '') {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Nama kategori wajib diisi.');
  } elseif ($jenis != 'masuk' && $jenis != 'keluar') {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Jenis kategori tidak valid.');
  } else {
    $namaEsc = mysqli_real_escape_string($conn, $nama);
    $jenisEsc = mysqli_real_escape_string($conn, $jenis);
    $cek = mysqli_query($conn, "SELECT id FROM kategori_transaksi WHERE nama_kategori = '$namaEsc' AND jenis = '$jenisEsc' AND id != $id");

    if (mysqli_num_rows($cek) > 0) {
      $_SESSION['flash'] = array('type' => 'error', 'message' => 'Kategori dengan nama dan jenis yang sama sudah ada.');
    } else {
      mysqli_query($conn, "UPDATE kategori_transaksi SET nama_kategori='$namaEsc', jenis='$jenisEsc' WHERE id=$id");
      $_SESSION['flash'] = array('type' => 'success', 'message' => 'Kategori berhasil diperbarui.');
    }
  }
  header('Location: kategori.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
  $id = (int) $_POST['delete_id'];
  $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM transaksi_kas WHERE kategori_id = $id"));
  if ($cek['jml'] > 0) {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Kategori tidak bisa dihapus karena sudah dipakai di transaksi.');
  } else {
    mysqli_query($conn, "DELETE FROM kategori_transaksi WHERE id = $id");
    $_SESSION['flash'] = array('type' => 'success', 'message' => 'Kategori berhasil dihapus.');
  }
  header('Location: kategori.php');
  exit;
}

$kategori = array();
$q = mysqli_query($conn, "SELECT * FROM kategori_transaksi ORDER BY jenis ASC, nama_kategori ASC");
if ($q) {
  while ($row = mysqli_fetch_assoc($q)) {
    $kategori[] = $row;
  }
}

$pageTitle = 'Kategori Transaksi';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(15px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .btn-hover-bounce {
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .card-modern {
    border: none;
    border-radius: 14px;
    background: #ffffff;
  }

  .bg-soft-success {
    background-color: rgba(46, 204, 113, 0.12) !important;
    color: #2ecc71 !important;
  }

  .bg-soft-danger {
    background-color: rgba(231, 76, 60, 0.12) !important;
    color: #e74c3c !important;
  }

  .btn-primary {
    background-color: #3867d6;
    border-color: #3867d6;
  }

  .btn-primary:hover {
    background-color: #2b5797;
    border-color: #2b5797;
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold"><i class="bi bi-tags me-2 text-primary"></i> Kelola Kategori Transaksi</h4>
    <small class="text-muted">Atur jenis dan pengelompokan transaksi kas masuk & keluar</small>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-4 col-md-5 animate-fade-up">
    <div class="card card-modern p-4 shadow-sm">
      <h6 class="fw-bold mb-3 text-dark border-bottom pb-2">
        <i class="bi bi-plus-circle text-primary me-1"></i> Tambah Kategori
      </h6>
      <form method="POST">
        <div class="mb-3">
          <label class="form-label text-muted small fw-semibold">Nama Kategori</label>
          <input type="text" name="nama_kategori" class="form-control rounded-3"
            placeholder="Contoh: Operasional Kantor" required>
        </div>
        <div class="mb-3">
          <label class="form-label text-muted small fw-semibold">Jenis Transaksi</label>
          <select name="jenis" class="form-select rounded-3">
            <option value="masuk">Kas Masuk</option>
            <option value="keluar">Kas Keluar</option>
          </select>
        </div>
        <button type="submit" name="tambah" class="btn btn-primary w-100 rounded-3 btn-hover-bounce fw-semibold">
          <i class="bi bi-plus-lg me-1"></i> Tambah Kategori
        </button>
      </form>
    </div>
  </div>

  <div class="col-lg-8 col-md-7 animate-fade-up">
    <div class="card card-modern p-3 shadow-sm">
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr class="small text-muted">
              <th>Nama Kategori</th>
              <th>Jenis</th>
              <th class="text-end">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($kategori)): ?>
              <tr>
                <td colspan="3" class="text-center py-4">
                  <div class="empty-state">
                    <i class="bi bi-tags fs-3 text-muted opacity-50 d-block mb-1"></i>
                    <p class="mb-0 text-muted small">Belum ada data kategori.</p>
                  </div>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($kategori as $k): ?>
                <tr>
                  <td class="fw-semibold text-dark"><?= htmlspecialchars($k['nama_kategori'], ENT_QUOTES, 'UTF-8') ?></td>
                  <td>
                    <?php if ($k['jenis'] === 'masuk'): ?>
                      <span class="badge bg-soft-success px-2 py-1"><i class="bi bi-arrow-down-circle me-1"></i> Kas
                        Masuk</span>
                    <?php else: ?>
                      <span class="badge bg-soft-danger px-2 py-1"><i class="bi bi-arrow-up-circle me-1"></i> Kas
                        Keluar</span>
                    <?php endif; ?>
                  </td>
                  <td class="text-end">
                    <button class="btn btn-sm btn-outline-primary rounded-2 btn-hover-bounce" data-bs-toggle="modal"
                      data-bs-target="#editModal<?= $k['id'] ?>" title="Edit">
                      <i class="bi bi-pencil-square"></i>
                    </button>
                    <form id="deleteKatForm<?= $k['id'] ?>" method="POST" style="display:inline;">
                      <input type="hidden" name="delete_id" value="<?= $k['id'] ?>">
                    </form>
                    <button class="btn btn-sm btn-outline-danger rounded-2 btn-hover-bounce"
                      data-confirm="Hapus kategori ini?" data-confirm-form="deleteKatForm<?= $k['id'] ?>" title="Hapus">
                      <i class="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php foreach ($kategori as $k): ?>
  <div class="modal fade" id="editModal<?= $k['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow" style="border-radius: 14px;">
        <form method="POST">
          <div class="modal-header border-bottom">
            <h6 class="modal-title fw-bold"><i class="bi bi-pencil-square text-primary me-1"></i> Edit Kategori</h6>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="edit_id" value="<?= $k['id'] ?>">
            <div class="mb-3">
              <label class="form-label text-muted small fw-semibold">Nama Kategori</label>
              <input type="text" name="edit_nama" class="form-control rounded-3"
                value="<?= htmlspecialchars($k['nama_kategori'], ENT_QUOTES, 'UTF-8') ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label text-muted small fw-semibold">Jenis Transaksi</label>
              <select name="edit_jenis" class="form-select rounded-3">
                <option value="masuk" <?= $k['jenis'] === 'masuk' ? 'selected' : '' ?>>Kas Masuk</option>
                <option value="keluar" <?= $k['jenis'] === 'keluar' ? 'selected' : '' ?>>Kas Keluar</option>
              </select>
            </div>
          </div>
          <div class="modal-footer border-top">
            <button type="button" class="btn btn-sm btn-outline-secondary rounded-3"
              data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="simpan_edit" class="btn btn-sm btn-primary rounded-3 fw-semibold"><i
                class="bi bi-save me-1"></i> Simpan Perubahan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php endforeach; ?>

<?php require '../includes/footer.php'; ?>