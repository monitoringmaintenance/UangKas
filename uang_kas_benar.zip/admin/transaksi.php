<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'admin') {
  header("Location: ../login.php");
  exit;
}

$jenis = isset($_GET['jenis']) ? $_GET['jenis'] : '';
$dari = isset($_GET['dari']) ? $_GET['dari'] : '';
$sampai = isset($_GET['sampai']) ? $_GET['sampai'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$kategoriId = isset($_GET['kategori_id']) ? $_GET['kategori_id'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'terbaru';
$page = max(1, (int) (isset($_GET['page']) ? $_GET['page'] : 1));
$perPage = 15;

$kategoriList = array();
$qk = mysqli_query($conn, "SELECT * FROM kategori_transaksi ORDER BY jenis, nama_kategori");
while ($row = mysqli_fetch_assoc($qk))
  $kategoriList[] = $row;

$where = array();
if ($jenis !== '' && ($jenis == 'masuk' || $jenis == 'keluar')) {
  $where[] = "t.jenis = '$jenis'";
}
if ($dari !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dari)) {
  $where[] = "t.tanggal >= '$dari'";
}
if ($sampai !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $sampai)) {
  $where[] = "t.tanggal <= '$sampai'";
}
if ($search !== '') {
  $where[] = "(t.keterangan LIKE '%$search%' OR k.nama_kategori LIKE '%$search%')";
}
if ($kategoriId !== '' && is_numeric($kategoriId)) {
  $where[] = "t.kategori_id = " . (int) $kategoriId;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$orderBy = 't.tanggal DESC, t.id DESC';
if ($sort === 'terlama')
  $orderBy = 't.tanggal ASC, t.id ASC';
elseif ($sort === 'jumlah_desc')
  $orderBy = 't.jumlah DESC';
elseif ($sort === 'jumlah_asc')
  $orderBy = 't.jumlah ASC';
elseif ($sort === 'kategori')
  $orderBy = 'k.nama_kategori ASC';

$totalItems = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM transaksi_kas t JOIN kategori_transaksi k ON k.id = t.kategori_id $whereSql"))['jml'];

$offset = ($page - 1) * $perPage;
$transaksi = array();
$q = mysqli_query($conn, "
    SELECT t.*, k.nama_kategori, u.nama_lengkap AS pencatat
    FROM transaksi_kas t
    JOIN kategori_transaksi k ON k.id = t.kategori_id
    JOIN users u ON u.id = t.created_by
    $whereSql
    ORDER BY $orderBy
    LIMIT $perPage OFFSET $offset
");
while ($row = mysqli_fetch_assoc($q))
  $transaksi[] = $row;

$totalMasukFiltered = 0;
$totalKeluarFiltered = 0;
$qAll = mysqli_query($conn, "SELECT t.jenis, t.jumlah FROM transaksi_kas t JOIN kategori_transaksi k ON k.id = t.kategori_id $whereSql");
while ($r = mysqli_fetch_assoc($qAll)) {
  if ($r['jenis'] === 'masuk')
    $totalMasukFiltered += $r['jumlah'];
  else
    $totalKeluarFiltered += $r['jumlah'];
}
$saldoFiltered = $totalMasukFiltered - $totalKeluarFiltered;

$pageTitle = 'Transaksi Kas';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes floatIcon {

    0%,
    100% {
      transform: translateY(0px);
    }

    50% {
      transform: translateY(-6px);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.5s ease-out forwards;
  }

  .stagger-children>* {
    opacity: 0;
    animation: fadeInUp 0.5s ease-out forwards;
  }

  .stagger-children>*:nth-child(1) {
    animation-delay: 0.1s;
  }

  .stagger-children>*:nth-child(2) {
    animation-delay: 0.2s;
  }

  .stagger-children>*:nth-child(3) {
    animation-delay: 0.3s;
  }

  .stagger-children>*:nth-child(4) {
    animation-delay: 0.4s;
  }

  .card-stat {
    border: none;
    border-radius: 12px;
    color: #fff;
    position: relative;
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .card-stat:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12) !important;
  }

  .card-stat .stat-icon {
    font-size: 2.5rem;
    position: absolute;
    right: 15px;
    top: 15px;
    opacity: 0.3;
    transition: all 0.3s ease;
  }

  .card-stat:hover .stat-icon {
    opacity: 0.6;
    animation: floatIcon 2s infinite ease-in-out;
  }

  .bg-masuk {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
  }

  .bg-keluar {
    background: linear-gradient(135deg, #cb2d3e 0%, #ef473a 100%);
  }

  .bg-saldo {
    background: linear-gradient(135deg, #2193b0 0%, #6dd5ed 100%);
  }

  .bg-pending {
    background: linear-gradient(135deg, #ff9966 0%, #ff5e62 100%);
  }

  .table-modern tbody tr {
    transition: all 0.2s ease;
  }

  .table-modern tbody tr:hover {
    background-color: rgba(13, 110, 253, 0.04) !important;
    transform: scale(1.002);
  }

  .btn-hover-bounce {
    transition: all 0.2s ease;
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold"><i class="bi bi-cash-coin me-1 text-primary"></i> Transaksi Kas</h4>
    <small class="text-muted">Kelola dan tinjau seluruh riwayat transaksi kas</small>
  </div>
  <a href="tambah_transaksi.php" class="btn btn-primary btn-sm px-3 shadow-sm btn-hover-bounce">
    <i class="bi bi-plus-lg me-1"></i> Catat Transaksi
  </a>
</div>

<?php if ($totalItems > 0): ?>
  <div class="row g-3 mb-4 stagger-children">
    <div class="col-md-3 col-6">
      <div class="card card-stat bg-masuk p-3 shadow-sm">
        <i class="bi bi-arrow-down-circle stat-icon"></i>
        <div class="stat-label small opacity-75 fw-semibold">TOTAL MASUK</div>
        <div class="stat-value fs-5 fw-bold mt-1"><?= formatRupiah($totalMasukFiltered) ?></div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="card card-stat bg-keluar p-3 shadow-sm">
        <i class="bi bi-arrow-up-circle stat-icon"></i>
        <div class="stat-label small opacity-75 fw-semibold">TOTAL KELUAR</div>
        <div class="stat-value fs-5 fw-bold mt-1"><?= formatRupiah($totalKeluarFiltered) ?></div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="card card-stat bg-saldo p-3 shadow-sm">
        <i class="bi bi-wallet2 stat-icon"></i>
        <div class="stat-label small opacity-75 fw-semibold">SALDO</div>
        <div class="stat-value fs-5 fw-bold mt-1"><?= formatRupiah($saldoFiltered) ?></div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="card card-stat bg-pending p-3 shadow-sm">
        <i class="bi bi-receipt stat-icon"></i>
        <div class="stat-label small opacity-75 fw-semibold">TOTAL TRANSAKSI</div>
        <div class="stat-value fs-5 fw-bold mt-1"><?= $totalItems ?></div>
      </div>
    </div>
  </div>
<?php endif; ?>

<div class="card p-3 mb-4 no-print animate-fade-up shadow-sm border-0">
  <div class="fw-bold mb-3 small text-secondary">
    <i class="bi bi-funnel-fill me-1 text-primary"></i> Filter & Pencarian Transaksi
  </div>
  <form method="GET" class="row g-3">
    <div class="col-lg-3 col-md-6">
      <label class="form-label small text-muted mb-1">Jenis Transaksi</label>
      <div class="input-group input-group-sm">
        <select name="jenis" class="form-select">
          <option value="">Semua Jenis</option>
          <option value="masuk" <?= $jenis === 'masuk' ? 'selected' : '' ?>>Kas Masuk</option>
          <option value="keluar" <?= $jenis === 'keluar' ? 'selected' : '' ?>>Kas Keluar</option>
        </select>
        <span class="input-group-text"><i class="bi bi-chevron-down"></i></span>
      </div>
    </div>

    <div class="col-lg-3 col-md-6">
      <label class="form-label small text-muted mb-1">Kategori</label>
      <div class="input-group input-group-sm">
        <select name="kategori_id" class="form-select">
          <option value="">Semua Kategori</option>
          <?php foreach ($kategoriList as $k): ?>
            <option value="<?= $k['id'] ?>" <?= (string) $kategoriId === (string) $k['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($k['nama_kategori']) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <span class="input-group-text"><i class="bi bi-chevron-down"></i></span>
      </div>
    </div>

    <div class="col-lg-3 col-md-6">
      <label class="form-label small text-muted mb-1">Dari Tanggal</label>
      <div class="input-group input-group-sm">
        <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
        <input type="date" name="dari" value="<?= htmlspecialchars($dari, ENT_QUOTES, 'UTF-8') ?>" class="form-control">
      </div>
    </div>

    <div class="col-lg-3 col-md-6">
      <label class="form-label small text-muted mb-1">Sampai Tanggal</label>
      <div class="input-group input-group-sm">
        <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
        <input type="date" name="sampai" value="<?= htmlspecialchars($sampai, ENT_QUOTES, 'UTF-8') ?>"
          class="form-control">
      </div>
    </div>

    <div class="col-12">
      <label class="form-label small text-muted mb-1">Cari Keterangan / Kategori</label>
      <div class="input-group input-group-sm">
        <span class="input-group-text"><i class="bi bi-search"></i></span>
        <input type="text" name="search" value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
          class="form-control" placeholder="Masukkan kata kunci keterangan atau kategori...">
      </div>
    </div>

    <input type="hidden" name="sort" value="<?= htmlspecialchars($sort) ?>">

    <div class="col-12 d-flex justify-content-end gap-2 pt-2 border-top">
      <a href="transaksi.php" class="btn btn-sm btn-outline-secondary px-3 btn-hover-bounce">
        <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
      </a>
      <button type="submit" class="btn btn-sm btn-primary px-4 btn-hover-bounce shadow-sm">
        <i class="bi bi-funnel me-1"></i> Terapkan Filter
      </button>
    </div>
  </form>
</div>

<div class="card p-0 animate-fade-up shadow-sm border-0 rounded-3">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0 table-modern text-nowrap">
      <thead class="table-light">
        <tr class="text-muted small">
          <th class="text-center" style="width: 50px;">No</th>
          <th style="width: 130px;">Tanggal</th>
          <th style="width: 180px;">Kategori</th>
          <th>Keterangan</th>
          <th style="width: 150px;">Dicatat Oleh</th>
          <th class="text-end" style="width: 150px;">Jumlah</th>
          <th class="text-center" style="width: 90px;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($transaksi)): ?>
          <tr>
            <td colspan="7">
              <div class="empty-state py-5 text-center text-muted">
                <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary opacity-50"></i>
                <h6 class="fw-bold text-muted">Tidak Ada Transaksi</h6>
                <p class="small mb-0">Belum ada data transaksi yang cocok dengan filter yang dipilih.</p>
              </div>
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($transaksi as $i => $t): ?>
            <tr>
              <td class="text-center text-muted small fw-semibold"><?= ($offset + $i + 1) ?></td>
              <td>
                <span class="d-inline-flex align-items-center gap-1 small">
                  <i class="bi bi-calendar3 text-muted"></i>
                  <?= formatTanggal($t['tanggal']) ?>
                </span>
              </td>
              <td>
                <div class="d-flex flex-column align-items-start gap-1">
                  <span class="fw-semibold small"><?= htmlspecialchars($t['nama_kategori']) ?></span>
                  <?= badgeJenis($t['jenis']) ?>
                </div>
              </td>
              <td>
                <span class="text-truncate d-inline-block small" style="max-width: 280px;"
                  title="<?= htmlspecialchars($t['keterangan']) ?>">
                  <?= htmlspecialchars($t['keterangan']) ?>
                </span>
              </td>
              <td>
                <span class="d-inline-flex align-items-center gap-1 small text-secondary">
                  <i class="bi bi-person-circle text-muted"></i>
                  <?= htmlspecialchars($t['pencatat']) ?>
                </span>
              </td>
              <td class="text-end">
                <span class="fw-bold small <?= $t['jenis'] === 'masuk' ? 'text-success' : 'text-danger' ?>">
                  <?= $t['jenis'] === 'masuk' ? '+' : '-' ?>     <?= formatRupiah($t['jumlah']) ?>
                </span>
              </td>
              <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-info btn-hover-bounce" data-bs-toggle="modal"
                  data-bs-target="#detailModal<?= $t['id'] ?>" title="Detail">
                  <i class="bi bi-eye"></i>
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
      <?php if (!empty($transaksi)): ?>
        <tfoot class="table-light border-top">
          <tr>
            <td colspan="5" class="text-end fw-bold align-middle small text-secondary">RINGKASAN TOTAL</td>
            <td class="text-end align-middle">
              <div class="small fw-bold text-success">+ <?= formatRupiah($totalMasukFiltered) ?></div>
              <div class="small fw-bold text-danger">- <?= formatRupiah($totalKeluarFiltered) ?></div>
              <div class="border-top my-1"></div>
              <div class="fw-bold text-primary fs-6"><?= formatRupiah($saldoFiltered) ?></div>
            </td>
            <td></td>
          </tr>
        </tfoot>
      <?php endif; ?>
    </table>
  </div>

  <?php if ($totalItems > 0): ?>
    <div class="px-3 py-3 border-top">
      <?php
      $queryParams = array();
      if ($jenis !== '')
        $queryParams['jenis'] = $jenis;
      if ($dari !== '')
        $queryParams['dari'] = $dari;
      if ($sampai !== '')
        $queryParams['sampai'] = $sampai;
      if ($search !== '')
        $queryParams['search'] = $search;
      if ($kategoriId !== '')
        $queryParams['kategori_id'] = $kategoriId;
      if ($sort !== 'terbaru')
        $queryParams['sort'] = $sort;
      echo renderPagination($page, $totalItems, $perPage, $queryParams);
      ?>
    </div>
  <?php endif; ?>
</div>

<?php foreach ($transaksi as $t): ?>
  <div class="modal fade" id="detailModal<?= $t['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow-lg rounded-3">
        <div class="modal-header border-bottom-0 pb-0">
          <h6 class="modal-title fw-bold text-primary"><i class="bi bi-receipt me-1"></i> Detail Transaksi</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="detail-row mb-2 d-flex justify-content-between">
            <span class="detail-label text-muted small">Tanggal</span>
            <span class="detail-value fw-semibold small"><?= formatTanggal($t['tanggal']) ?></span>
          </div>
          <div class="detail-row mb-2 d-flex justify-content-between align-items-center">
            <span class="detail-label text-muted small">Jenis</span>
            <span class="detail-value"><?= badgeJenis($t['jenis']) ?></span>
          </div>
          <div class="detail-row mb-2 d-flex justify-content-between">
            <span class="detail-label text-muted small">Kategori</span>
            <span class="detail-value fw-semibold small"><?= htmlspecialchars($t['nama_kategori']) ?></span>
          </div>
          <div class="detail-row mb-2 d-flex justify-content-between">
            <span class="detail-label text-muted small">Keterangan</span>
            <span class="detail-value text-end small"
              style="max-width: 60%;"><?= htmlspecialchars($t['keterangan']) ?></span>
          </div>
          <div class="detail-row mb-2 d-flex justify-content-between">
            <span class="detail-label text-muted small">Jumlah</span>
            <span class="detail-value fw-bold <?= $t['jenis'] === 'masuk' ? 'text-success' : 'text-danger' ?>">
              <?= $t['jenis'] === 'masuk' ? '+' : '-' ?>   <?= formatRupiah($t['jumlah']) ?>
            </span>
          </div>
          <div class="detail-row mb-2 d-flex justify-content-between">
            <span class="detail-label text-muted small">Dicatat Oleh</span>
            <span class="detail-value small fw-semibold"><?= htmlspecialchars($t['pencatat']) ?></span>
          </div>
          <div class="detail-row mb-2 d-flex justify-content-between">
            <span class="detail-label text-muted small">Waktu Input</span>
            <span class="detail-value text-muted small"><?= formatTanggalWaktu($t['created_at']) ?></span>
          </div>
          <?php if (!empty($t['pengajuan_id'])): ?>
            <div class="detail-row d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
              <span class="detail-label text-muted small">Pengajuan</span>
              <span class="detail-value">
                <span class="badge bg-info bg-opacity-10 text-info border border-info border-opacity-25"><i
                    class="bi bi-link-45deg me-1"></i> #<?= $t['pengajuan_id'] ?></span>
              </span>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; ?>

<?php require '../includes/footer.php'; ?>