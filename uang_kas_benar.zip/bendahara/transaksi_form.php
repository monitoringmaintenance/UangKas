<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'bendahara') {
  header("Location: ../login.php");
  exit;
}

$id = isset($_GET['id']) ? $_GET['id'] : null;
$isEdit = false;
$error = '';
$data = array(
  'tanggal' => date('Y-m-d'),
  'jenis' => 'masuk',
  'kategori_id' => '',
  'keterangan' => '',
  'jumlah' => '',
);

if ($id) {
  $id = (int) $id;
  $stmt = mysqli_prepare($conn, "SELECT * FROM transaksi_kas WHERE id = ?");
  mysqli_stmt_bind_param($stmt, "i", $id);
  mysqli_stmt_execute($stmt);
  $res = mysqli_stmt_get_result($stmt);
  $found = mysqli_fetch_assoc($res);

  if ($found) {
    if (!empty($found['pengajuan_id'])) {
      $_SESSION['flash'] = array('type' => 'error', 'message' => 'Transaksi hasil pengajuan HRD tidak bisa diubah manual.');
      header('Location: transaksi.php');
      exit;
    }
    $data = $found;
    $isEdit = true;
  } else {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Transaksi tidak ditemukan.');
    header('Location: transaksi.php');
    exit;
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $tanggal = $_POST['tanggal'];
  $jenis = $_POST['jenis'];
  $kategoriId = $_POST['kategori_id'];
  $keterangan = trim($_POST['keterangan']);
  $jumlah = str_replace(array('.', ','), '', $_POST['jumlah']);

  $minJumlah = 5000;

  if ($jenis != 'masuk' && $jenis != 'keluar') {
    $error = 'Jenis transaksi tidak valid.';
  } elseif ($tanggal === '' || $kategoriId === '' || $keterangan === '' || $jumlah === '' || !is_numeric($jumlah)) {
    $error = 'Semua field wajib diisi dengan benar.';
  } elseif ((float) $jumlah < $minJumlah) {
    $error = 'Jumlah transaksi minimal adalah ' . formatRupiah($minJumlah) . '.';
  } else {
    $kategoriIdInt = (int) $kategoriId;
    $stmtKat = mysqli_prepare($conn, "SELECT id FROM kategori_transaksi WHERE id = ?");
    mysqli_stmt_bind_param($stmtKat, "i", $kategoriIdInt);
    mysqli_stmt_execute($stmtKat);
    $resKat = mysqli_stmt_get_result($stmtKat);
    $cekKat = mysqli_fetch_assoc($resKat);

    if (!$cekKat) {
      $error = 'Kategori yang dipilih tidak valid.';
    } else {
      if ($isEdit) {
        $stmt = mysqli_prepare($conn, "UPDATE transaksi_kas SET tanggal=?, jenis=?, kategori_id=?, keterangan=?, jumlah=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssisdi", $tanggal, $jenis, $kategoriIdInt, $keterangan, $jumlah, $id);
        mysqli_stmt_execute($stmt);
        $_SESSION['flash'] = array('type' => 'success', 'message' => 'Transaksi berhasil diperbarui.');
      } else {
        $uid = $_SESSION['user_id'];
        $stmt = mysqli_prepare($conn, "INSERT INTO transaksi_kas (tanggal, jenis, kategori_id, keterangan, jumlah, created_by) VALUES (?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssisdi", $tanggal, $jenis, $kategoriIdInt, $keterangan, $jumlah, $uid);
        mysqli_stmt_execute($stmt);
        $_SESSION['flash'] = array('type' => 'success', 'message' => 'Transaksi baru berhasil dicatat.');
      }
      header('Location: transaksi.php');
      exit;
    }
  }
  $data = array('tanggal' => $tanggal, 'jenis' => $jenis, 'kategori_id' => $kategoriId, 'keterangan' => $keterangan, 'jumlah' => $jumlah);
}

$kategoriList = array();
$qk = mysqli_query($conn, "SELECT * FROM kategori_transaksi ORDER BY jenis, nama_kategori");
while ($row = mysqli_fetch_assoc($qk)) {
  $kategoriList[] = $row;
}

$pageTitle = $isEdit ? 'Edit Transaksi' : 'Catat Transaksi';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(15px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .btn-hover-bounce {
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .card-form {
    border: none;
    border-radius: 14px;
    background: #ffffff;
  }

  .form-control:focus,
  .form-select:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
  }

  .input-group-text {
    background-color: #f8f9fa;
    border-right: none;
  }

  .input-group .form-control {
    border-left: none;
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold">
      <i class="bi bi-cash-coin me-1 text-primary"></i>
      <?= $isEdit ? 'Edit Transaksi' : 'Catat Transaksi Kas' ?>
    </h4>
    <small class="text-muted"><?= $isEdit ? 'Perbarui rincian data transaksi kas' : 'Tambahkan pencatatan kas masuk atau kas keluar baru' ?></small>
  </div>
</div>

<div class="row g-4 animate-fade-up">
  <div class="col-12 col-xl-8">
    <div class="card card-form p-4 shadow-sm">
      <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show py-2 px-3 small d-flex align-items-center gap-2 mb-4" role="alert">
          <i class="bi bi-exclamation-triangle-fill fs-6 flex-shrink-0"></i>
          <div><?= htmlspecialchars($error) ?></div>
          <button type="button" class="btn-close shadow-none py-2" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endif; ?>

      <form method="POST" id="transaksiForm" novalidate>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label small fw-semibold text-secondary mb-1">
              Tanggal Transaksi <span class="text-danger">*</span>
            </label>
            <div class="input-group">
              <span class="input-group-text text-muted"><i class="bi bi-calendar3"></i></span>
              <input type="date" name="tanggal" class="form-control" value="<?= htmlspecialchars($data['tanggal']) ?>" required>
            </div>
          </div>

          <div class="col-md-6">
            <label class="form-label small fw-semibold text-secondary mb-1">
              Jenis Transaksi <span class="text-danger">*</span>
            </label>
            <div class="input-group">
              <span class="input-group-text text-muted"><i class="bi bi-arrow-left-right"></i></span>
              <select name="jenis" id="jenisSelect" class="form-select fw-semibold" required>
                <option value="masuk" <?= $data['jenis'] === 'masuk' ? 'selected' : '' ?>>Kas Masuk (+)</option>
                <option value="keluar" <?= $data['jenis'] === 'keluar' ? 'selected' : '' ?>>Kas Keluar (-)</option>
              </select>
            </div>
          </div>

          <div class="col-12">
            <label class="form-label small fw-semibold text-secondary mb-1">
              Kategori Transaksi <span class="text-danger">*</span>
            </label>
            <div class="input-group">
              <span class="input-group-text text-muted"><i class="bi bi-tag"></i></span>
              <select name="kategori_id" id="kategoriSelect" class="form-select" required>
                <option value="">-- Pilih Kategori --</option>
                <?php foreach ($kategoriList as $k): ?>
                  <option value="<?= $k['id'] ?>" data-jenis="<?= $k['jenis'] ?>" <?= (string) $data['kategori_id'] === (string) $k['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($k['nama_kategori']) ?> (<?= $k['jenis'] === 'masuk' ? 'Masuk' : 'Keluar' ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="col-12">
            <label class="form-label small fw-semibold text-secondary mb-1">
              Keterangan / Deskripsi <span class="text-danger">*</span>
            </label>
            <div class="input-group">
              <span class="input-group-text text-muted"><i class="bi bi-card-text"></i></span>
              <input type="text" name="keterangan" class="form-control"  value="<?= htmlspecialchars($data['keterangan']) ?>" required>
            </div>
          </div>

          <div class="col-12">
            <label class="form-label small fw-semibold text-secondary mb-1">
              Jumlah (Rp) <span class="text-danger">*</span>
            </label>
            <div class="input-group">
              <span class="input-group-text fw-bold text-primary">Rp</span>
              <input type="number" step="1" min="1000" name="jumlah" class="form-control fs-5 fw-bold text-primary" placeholder="0" value="<?= htmlspecialchars($data['jumlah']) ?>" required>
            </div>
          </div>

          <div class="col-12 d-flex gap-2 pt-3 border-top mt-4">
            <button type="submit" class="btn btn-primary px-4 btn-hover-bounce shadow-sm" id="submitBtn">
              <i class="bi bi-save me-1"></i> <?= $isEdit ? 'Perbarui' : 'Simpan Transaksi' ?>
            </button>
            <a href="transaksi.php" class="btn btn-outline-secondary px-4 btn-hover-bounce">
              Batal
            </a>
          </div>

        </div>
      </form>
    </div>
  </div>

  <div class="col-12 col-xl-4">
    <div class="card card-form p-4 shadow-sm border-0 bg-light">
      <h6 class="fw-bold text-primary mb-3">
        <i class="bi bi-info-circle-fill me-1"></i> Panduan Pengisian
      </h6>
      <ul class="small text-secondary ps-3 mb-0 lh-lg">
        <li>Pastikan memilih <strong>Tanggal Transaksi</strong> yang sesuai dengan kejadian aslinya.</li>
        <li>Pilih <strong>Jenis Transaksi</strong> (Kas Masuk atau Kas Keluar) agar kategori yang muncul sesuai.</li>
        <li>Isi <strong>Keterangan</strong> secara jelas dan deskriptif (contoh: <em>Pembelian ATK Kantor</em>).</li>
        <li>Masukkan nominal <strong>Jumlah</strong> angka saja minimal Rp 5.000 tanpa simbol mata uang.</li>
      </ul>
    </div>
  </div>
</div>

<script>
  const jenisSelect = document.getElementById('jenisSelect');
  const kategoriSelect = document.getElementById('kategoriSelect');

  function filterKategori() {
    const jenis = jenisSelect.value;
    let firstVisible = null;
    [...kategoriSelect.options].forEach(opt => {
      if (!opt.value) return;
      const match = opt.dataset.jenis === jenis;
      opt.hidden = !match;
      if (match && !firstVisible) firstVisible = opt;
    });

    if (kategoriSelect.value && [...kategoriSelect.options].find(o => o.value === kategoriSelect.value)?.dataset.jenis !== jenis) {
      kategoriSelect.value = '';
    }
  }

  jenisSelect.addEventListener('change', filterKategori);
  filterKategori();

  document.getElementById('transaksiForm').addEventListener('submit', function () {
    const btn = document.getElementById('submitBtn');
    btn.classList.add('disabled');
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Menyimpan...';
  });
</script>

<?php require '../includes/footer.php'; ?>