<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'bendahara') {
  header("Location: ../login.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
  $id = (int) $_POST['id'];
  $aksi = $_POST['aksi'];
  $catatan = trim(isset($_POST['catatan']) ? $_POST['catatan'] : '');

  if ($aksi != 'setuju' && $aksi != 'tolak') {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Aksi tidak valid.');
    header('Location: pengajuan.php');
    exit;
  }

  if ($aksi === 'tolak' && $catatan === '') {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Catatan wajib diisi saat menolak pengajuan.');
    header('Location: pengajuan.php');
    exit;
  }

  $pengajuan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pengajuan_dana WHERE id = $id AND status = 'pending'"));

  if (!$pengajuan) {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Pengajuan tidak ditemukan atau sudah diproses.');
  } else {
    $uid = (int) $_SESSION['user_id'];
    $catatan_clean = mysqli_real_escape_string($conn, $catatan);

    if ($aksi === 'setuju') {
      $katRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM kategori_transaksi WHERE nama_kategori = 'Reimburse / Pengajuan HRD' AND jenis='keluar' LIMIT 1"));
      if ($katRow) {
        $kategoriId = (int) $katRow['id'];
      } else {
        mysqli_query($conn, "INSERT INTO kategori_transaksi (nama_kategori, jenis) VALUES ('Reimburse / Pengajuan HRD', 'keluar')");
        $kategoriId = mysqli_insert_id($conn);
      }

      $keterangan = 'Pencairan dana pengajuan HRD: ' . $pengajuan['keperluan'];
      $keterangan_clean = mysqli_real_escape_string($conn, $keterangan);
      $jumlah_clean = (float) $pengajuan['jumlah'];

      mysqli_query($conn, "
                INSERT INTO transaksi_kas (tanggal, jenis, kategori_id, keterangan, jumlah, pengajuan_id, created_by)
                VALUES (CURDATE(), 'keluar', $kategoriId, '$keterangan_clean', $jumlah_clean, $id, $uid)
            ");

      mysqli_query($conn, "
                UPDATE pengajuan_dana
                SET status='disetujui', catatan_bendahara='$catatan_clean', diproses_oleh=$uid, tanggal_diproses=NOW()
                WHERE id=$id
            ");
      $_SESSION['flash'] = array('type' => 'success', 'message' => 'Pengajuan disetujui & transaksi kas keluar otomatis dibuat.');
    } else {
      mysqli_query($conn, "
                UPDATE pengajuan_dana
                SET status='ditolak', catatan_bendahara='$catatan_clean', diproses_oleh=$uid, tanggal_diproses=NOW()
                WHERE id=$id
            ");
      $_SESSION['flash'] = array('type' => 'success', 'message' => 'Pengajuan ditolak.');
    }
  }
  header('Location: pengajuan.php');
  exit;
}

$status = isset($_GET['status']) ? $_GET['status'] : 'pending';
$allowedStatuses = array('pending', 'disetujui', 'ditolak', 'semua');
if (!in_array($status, $allowedStatuses)) {
  $status = 'pending';
}

$counts = array(
  'pending' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM pengajuan_dana WHERE status = 'pending'"))['jml'],
  'disetujui' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM pengajuan_dana WHERE status = 'disetujui'"))['jml'],
  'ditolak' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM pengajuan_dana WHERE status = 'ditolak'"))['jml'],
);
$counts['semua'] = $counts['pending'] + $counts['disetujui'] + $counts['ditolak'];

$where = $status !== 'semua' ? "WHERE p.status = '$status'" : '';

$daftar = array();
$q = mysqli_query($conn, "
    SELECT p.*, u.nama_lengkap AS nama_hrd
    FROM pengajuan_dana p
    JOIN users u ON u.id = p.hrd_id
    $where
    ORDER BY p.created_at DESC
");
while ($row = mysqli_fetch_assoc($q)) {
  $daftar[] = $row;
}

$pageTitle = 'Pengajuan Dana';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(15px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .stagger-children>* {
    opacity: 0;
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .stagger-children>*:nth-child(1) {
    animation-delay: 0.05s;
  }

  .stagger-children>*:nth-child(2) {
    animation-delay: 0.1s;
  }

  .stagger-children>*:nth-child(3) {
    animation-delay: 0.15s;
  }

  .stagger-children>*:nth-child(4) {
    animation-delay: 0.2s;
  }

  .stagger-children>*:nth-child(5) {
    animation-delay: 0.25s;
  }

  .stagger-children>*:nth-child(6) {
    animation-delay: 0.3s;
  }

  .btn-hover-bounce {
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .card-pengajuan {
    border: none;
    border-radius: 14px;
    background: #ffffff;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .card-pengajuan:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.08) !important;
  }

  .nav-pills-custom .nav-link {
    border-radius: 10px;
    color: #6c757d;
    font-weight: 500;
    padding: 8px 16px;
    transition: all 0.2s ease;
  }

  .nav-pills-custom .nav-link.active {
    background-color: #0d6efd;
    color: #fff;
    box-shadow: 0 4px 10px rgba(13, 110, 253, 0.25);
  }

  .nav-pills-custom .nav-link:hover:not(.active) {
    background-color: #e9ecef;
    color: #212529;
  }

  .bg-soft-danger {
    background-color: rgba(220, 53, 69, 0.1);
    color: #dc3545;
  }

  .bg-soft-success {
    background-color: rgba(25, 135, 84, 0.1);
    color: #198754;
  }

  .timeline {
    position: relative;
    padding-left: 20px;
    border-left: 2px solid #e9ecef;
  }

  .timeline-item {
    position: relative;
    margin-bottom: 8px;
  }

  .timeline-item:last-child {
    margin-bottom: 0;
  }

  .timeline-dot {
    position: absolute;
    left: -26px;
    top: 4px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
  }

  .dot-success {
    background-color: #198754;
  }

  .dot-danger {
    background-color: #dc3545;
  }

  .dot-warning {
    background-color: #ffc107;
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold"><i class="bi bi-inbox-fill me-1 text-primary"></i> Pengajuan Dana HRD</h4>
    <small class="text-muted">Tinjau dan proses permohonan dana dari tim HRD</small>
  </div>
</div>

<ul class="nav nav-pills nav-pills-custom mb-4 animate-fade-up gap-2">
  <?php foreach (array('pending' => 'Menunggu', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak', 'semua' => 'Semua') as $key => $label): ?>
    <li class="nav-item">
      <a class="nav-link d-flex align-items-center gap-2 <?php echo $status === $key ? 'active' : ''; ?>"
        href="?status=<?php echo $key; ?>">
        <i
          class="bi bi-<?php echo $key === 'pending' ? 'clock-history' : ($key === 'disetujui' ? 'check-circle' : ($key === 'ditolak' ? 'x-circle' : 'grid')); ?>"></i>
        <span><?php echo $label; ?></span>
        <span
          class="badge <?php echo $status === $key ? 'bg-white text-primary' : 'bg-secondary bg-opacity-10 text-secondary'; ?> rounded-pill px-2">
          <?php echo $counts[$key]; ?>
        </span>
      </a>
    </li>
  <?php endforeach; ?>
</ul>

<div class="row g-3 stagger-children">
  <?php if (empty($daftar)): ?>
    <div class="col-12">
      <div class="card card-pengajuan p-5 text-center text-muted shadow-sm">
        <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary opacity-50"></i>
        <h6 class="fw-bold text-muted">Tidak Ada Pengajuan</h6>
        <p class="small mb-0">Tidak ada pengajuan dana yang ditemukan pada kategori ini.</p>
      </div>
    </div>
  <?php endif; ?>

  <?php foreach ($daftar as $p): ?>
    <div class="col-md-6 col-lg-6">
      <div class="card card-pengajuan p-4 shadow-sm h-100 d-flex flex-column justify-content-between">
        <div>
          <div class="d-flex justify-content-between align-items-start mb-2">
            <h6 class="fw-bold text-dark mb-0 pe-2" style="line-height: 1.4;">
              <?php echo htmlspecialchars($p['keperluan'], ENT_QUOTES, 'UTF-8'); ?>
            </h6>
            <?php
            $st = strtolower($p['status']);
            if ($st === 'disetujui') {
              echo '<span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1"><i class="bi bi-check-circle me-1"></i>Disetujui</span>';
            } elseif ($st === 'ditolak') {
              echo '<span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-2 py-1"><i class="bi bi-x-circle me-1"></i>Ditolak</span>';
            } else {
              echo '<span class="badge bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25 px-2 py-1"><i class="bi bi-clock me-1"></i>Pending</span>';
            }
            ?>
          </div>

          <div class="small text-muted mb-3 d-flex flex-wrap gap-3">
            <span><i
                class="bi bi-person me-1 text-primary"></i><?php echo htmlspecialchars($p['nama_hrd'], ENT_QUOTES, 'UTF-8'); ?></span>
            <span><i
                class="bi bi-calendar3 me-1 text-primary"></i><?php echo function_exists('formatTanggal') ? formatTanggal($p['tanggal_pengajuan']) : date('d/m/Y', strtotime($p['tanggal_pengajuan'])); ?></span>
          </div>

          <div class="fw-bold text-primary fs-4 mb-3">
            <?php echo function_exists('formatRupiah') ? formatRupiah($p['jumlah']) : 'Rp ' . number_format($p['jumlah'], 0, ',', '.'); ?>
          </div>

          <?php if ($p['status'] !== 'pending' && !empty($p['catatan_bendahara'])): ?>
            <div
              class="small mb-3 p-3 rounded-3 <?php echo $p['status'] === 'ditolak' ? 'bg-soft-danger' : 'bg-soft-success'; ?>">
              <div class="fw-semibold mb-1"><i class="bi bi-chat-left-text me-1"></i> Catatan Bendahara:</div>
              <div class="text-break"><?php echo htmlspecialchars($p['catatan_bendahara'], ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
          <?php endif; ?>
        </div>

        <div>
          <?php if ($p['status'] === 'pending'): ?>
            <form method="POST" action="pengajuan.php" class="mt-3 pt-3 border-top"
              onsubmit="return confirm('Apakah Anda yakin ingin memproses pengajuan ini?');">
              <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
              <div class="mb-3">
                <textarea name="catatan" class="form-control form-control-sm"
                  placeholder="Tambahkan catatan (wajib diisi jika menolak)..." rows="2"></textarea>
              </div>
              <div class="d-flex gap-2">
                <button type="submit" name="aksi" value="setuju"
                  class="btn btn-success btn-sm flex-fill btn-hover-bounce shadow-sm fw-semibold">
                  <i class="bi bi-check-lg me-1"></i> Setujui
                </button>
                <button type="submit" name="aksi" value="tolak"
                  class="btn btn-outline-danger btn-sm flex-fill btn-hover-bounce fw-semibold">
                  <i class="bi bi-x-lg me-1"></i> Tolak
                </button>
              </div>
            </form>
          <?php else: ?>
            <div class="timeline mt-3 pt-3 border-top">
              <div class="timeline-item">
                <div class="timeline-dot dot-warning"></div>
                <div class="small">
                  <span class="fw-semibold text-dark">Pengajuan Dibuat</span>
                  <span class="text-muted"> &mdash;
                    <?php echo function_exists('formatTanggal') ? formatTanggal($p['tanggal_pengajuan']) : date('d/m/Y', strtotime($p['tanggal_pengajuan'])); ?></span>
                </div>
              </div>
              <?php if ($p['status'] === 'disetujui'): ?>
                <div class="timeline-item">
                  <div class="timeline-dot dot-success"></div>
                  <div class="small">
                    <span class="fw-semibold text-success">Disetujui & Kas Keluar Dibuat</span>
                    <?php if (!empty($p['tanggal_diproses'])): ?>
                      <span class="text-muted"> &mdash;
                        <?php echo function_exists('formatTanggalWaktu') ? formatTanggalWaktu($p['tanggal_diproses']) : date('d/m/Y H:i', strtotime($p['tanggal_diproses'])); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              <?php elseif ($p['status'] === 'ditolak'): ?>
                <div class="timeline-item">
                  <div class="timeline-dot dot-danger"></div>
                  <div class="small">
                    <span class="fw-semibold text-danger">Ditolak</span>
                    <?php if (!empty($p['tanggal_diproses'])): ?>
                      <span class="text-muted"> &mdash;
                        <?php echo function_exists('formatTanggalWaktu') ? formatTanggalWaktu($p['tanggal_diproses']) : date('d/m/Y H:i', strtotime($p['tanggal_diproses'])); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endif; ?>
            </div>
          <?php endif; ?>
        </div>

      </div>
    </div>
  <?php endforeach; ?>
</div>

</html>
<?php require '../includes/footer.php'; ?>