<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}
if ($_SESSION['role'] != 'bendahara') {
    header("Location: ../login.php");
    exit;
}

$dari_tanggal = isset($_GET['dari_tanggal']) ? $_GET['dari_tanggal'] : date('Y-m-01');
$sampai_tanggal = isset($_GET['sampai_tanggal']) ? $_GET['sampai_tanggal'] : date('Y-m-d');
$jenis = isset($_GET['jenis']) ? $_GET['jenis'] : '';
$kategori_id = isset($_GET['kategori_id']) ? $_GET['kategori_id'] : '';

$kategori_list = array();
$q_kat = mysqli_query($conn, "SELECT * FROM kategori_transaksi ORDER BY nama_kategori ASC");
while ($kat = mysqli_fetch_assoc($q_kat)) {
    $kategori_list[] = $kat;
}

$saldo = getSaldoKas($conn);
$saldoPeriode = getSaldoKas($conn, $dari_tanggal, $sampai_tanggal);
$totalPending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM pengajuan_dana WHERE status = 'pending'"))['jml'];
$totalTransaksi = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM transaksi_kas"))['jml'];
$totalDisetujui = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM pengajuan_dana WHERE status='disetujui'"))['jml'];

$query_transaksi = "
    SELECT t.*, k.nama_kategori FROM transaksi_kas t
    JOIN kategori_transaksi k ON k.id = t.kategori_id
    WHERE t.tanggal BETWEEN '$dari_tanggal' AND '$sampai_tanggal'
";

if (!empty($jenis)) {
    $query_transaksi .= " AND t.jenis = '$jenis'";
}
if (!empty($kategori_id)) {
    $query_transaksi .= " AND t.kategori_id = '$kategori_id'";
}

$query_transaksi .= " ORDER BY t.tanggal DESC, t.id DESC LIMIT 5";

$transaksiTerbaru = array();
$q1 = mysqli_query($conn, $query_transaksi);
while ($row = mysqli_fetch_assoc($q1)) {
    $transaksiTerbaru[] = $row;
}

$pengajuanPending = array();
$q2 = mysqli_query($conn, "
    SELECT p.*, u.nama_lengkap AS nama_hrd
    FROM pengajuan_dana p
    JOIN users u ON u.id = p.hrd_id
    WHERE p.status = 'pending'
    ORDER BY p.created_at DESC LIMIT 5
");
while ($row = mysqli_fetch_assoc($q2)) {
    $pengajuanPending[] = $row;
}

$pageTitle = 'Dashboard Bendahara';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes floatIcon {
    0%, 100% {
      transform: translateY(0px);
    }
    50% {
      transform: translateY(-6px);
    }
  }

  @keyframes pulseBadge {
    0% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.05);
    }
    100% {
      transform: scale(1);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.5s ease-out forwards;
  }

  .stagger-children>* {
    opacity: 0;
    animation: fadeInUp 0.5s ease-out forwards;
  }

  .stagger-children>*:nth-child(1) {
    animation-delay: 0.1s;
  }

  .stagger-children>*:nth-child(2) {
    animation-delay: 0.2s;
  }

  .stagger-children>*:nth-child(3) {
    animation-delay: 0.3s;
  }

  .stagger-children>*:nth-child(4) {
    animation-delay: 0.4s;
  }

  .card-stat {
    border: none;
    border-radius: 12px;
    color: #fff;
    position: relative;
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .card-stat:hover {
    transform: translateY(-6px);
    box-shadow: 0 12px 20px rgba(0, 0, 0, 0.15) !important;
  }

  .card-stat .stat-icon {
    font-size: 2.5rem;
    position: absolute;
    right: 15px;
    top: 15px;
    opacity: 0.3;
    transition: all 0.3s ease;
  }

  .card-stat:hover .stat-icon {
    opacity: 0.6;
    animation: floatIcon 2s infinite ease-in-out;
  }

  .bg-masuk {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
  }

  .bg-keluar {
    background: linear-gradient(135deg, #cb2d3e 0%, #ef473a 100%);
  }

  .bg-saldo {
    background: linear-gradient(135deg, #2193b0 0%, #6dd5ed 100%);
  }

  .bg-pending {
    background: linear-gradient(135deg, #ff9966 0%, #ff5e62 100%);
  }

  .table-modern tbody tr {
    transition: all 0.2s ease;
  }

  .table-modern tbody tr:hover {
    background-color: rgba(13, 110, 253, 0.04) !important;
    transform: scale(1.005);
  }

  .btn-hover-bounce {
    transition: all 0.2s ease;
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .badge-pulse {
    animation: pulseBadge 2s infinite;
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-3 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold"><i class="bi bi-speedometer2 me-1 text-primary"></i> Dashboard Bendahara</h4>
  </div>
</div>

<div class="row g-3 mb-4 stagger-children">
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-masuk p-3 h-100 shadow-sm">
      <i class="bi bi-arrow-down-circle stat-icon"></i>
      <div class="stat-label small opacity-75 fw-semibold">Total Kas Masuk</div>
      <div class="stat-value fs-5 fw-bold mt-1"><?= formatRupiah($saldo['masuk']) ?></div>
      <div class="small mt-2 pt-2 border-top border-white-50 opacity-75">Periode:
        <?= formatRupiah($saldoPeriode['masuk']) ?>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-keluar p-3 h-100 shadow-sm">
      <i class="bi bi-arrow-up-circle stat-icon"></i>
      <div class="stat-label small opacity-75 fw-semibold">Total Kas Keluar</div>
      <div class="stat-value fs-5 fw-bold mt-1"><?= formatRupiah($saldo['keluar']) ?></div>
      <div class="small mt-2 pt-2 border-top border-white-50 opacity-75">Periode:
        <?= formatRupiah($saldoPeriode['keluar']) ?>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-saldo p-3 h-100 shadow-sm">
      <i class="bi bi-wallet2 stat-icon"></i>
      <div class="stat-label small opacity-75 fw-semibold">Saldo Kas</div>
      <div class="stat-value fs-4 fw-bold mt-1"><?= formatRupiah($saldo['saldo']) ?></div>
      <div class="small mt-2 opacity-75">Status Kas Aktif</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-pending p-3 h-100 shadow-sm">
      <i class="bi bi-hourglass-split stat-icon"></i>
      <div class="stat-label small opacity-75 fw-semibold">Pengajuan Pending</div>
      <div class="stat-value fs-4 fw-bold mt-1"><?= $totalPending ?></div>
      <?php if ($totalPending > 0): ?>
        <a href="pengajuan.php"
          class="text-white small mt-2 d-inline-block fw-bold text-decoration-none badge bg-white bg-opacity-25 badge-pulse">
          Proses sekarang &rarr;
        </a>
      <?php else: ?>
        <div class="small mt-2 opacity-75">Membutuhkan Persetujuan</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="row g-3 stagger-children">
  <div class="col-lg-8">
    <div class="card card-modern p-4 mb-3 no-print shadow-sm border-0">
      <div class="fw-bold mb-3 small text-secondary d-flex align-items-center gap-1">
        <i class="bi bi-funnel-fill text-primary"></i> Filter Transaksi & Ringkasan Kas
      </div>
      <form method="GET" action="" class="row g-3">
        <div class="col-lg-3 col-md-6">
          <label class="form-label text-muted small mb-1 fw-semibold">Dari Tanggal</label>
          <div class="input-group input-group-sm">
            <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
            <input type="date" name="dari_tanggal" class="form-control"
              value="<?= htmlspecialchars($dari_tanggal, ENT_QUOTES, 'UTF-8') ?>">
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <label class="form-label text-muted small mb-1 fw-semibold">Sampai Tanggal</label>
          <div class="input-group input-group-sm">
            <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
            <input type="date" name="sampai_tanggal" class="form-control"
              value="<?= htmlspecialchars($sampai_tanggal, ENT_QUOTES, 'UTF-8') ?>">
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <label class="form-label small text-muted mb-1">Jenis</label>
          <div class="input-group input-group-sm">
            <select name="jenis" class="form-select">
              <option value="">Semua Jenis</option>
              <option value="masuk" <?= $jenis === 'masuk' ? 'selected' : '' ?>>Kas Masuk</option>
              <option value="keluar" <?= $jenis === 'keluar' ? 'selected' : '' ?>>Kas Keluar</option>
            </select>
            <span class="input-group-text"><i class="bi bi-chevron-down"></i></span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <label class="form-label text-muted small mb-1 fw-semibold">Kategori</label>
          <div class="input-group input-group-sm">
            <select name="kategori_id" class="form-select">
              <option value="">Semua Kategori</option>
              <?php if (!empty($kategori_list)): ?>
                <?php foreach ($kategori_list as $kat): ?>
                  <option value="<?= $kat['id'] ?>" <?= (string) $kategori_id === (string) $kat['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($kat['nama_kategori'], ENT_QUOTES, 'UTF-8') ?>
                  </option>
                <?php endforeach; ?>
              <?php endif; ?>
            </select>
            <span class="input-group-text"><i class="bi bi-chevron-down"></i></span>
          </div>
        </div>

        <div class="col-12 d-flex justify-content-end gap-2 pt-2 border-top">
          <a href="dashboard.php" class="btn btn-sm btn-outline-secondary px-3 btn-hover-bounce" title="Reset Filter">
            <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
          </a>
          <button type="submit" class="btn btn-sm btn-primary px-4 btn-hover-bounce shadow-sm">
            <i class="bi bi-funnel me-1"></i> Tampilkan
          </button>
        </div>
      </form>
    </div>

    <div class="card p-3 shadow-sm border-0 mb-3 rounded-3">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold mb-0">
          <i class="bi bi-clock-history me-1 text-primary"></i> Transaksi Terbaru
        </h6>
        <a href="transaksi.php" class="small text-decoration-none btn-hover-bounce">Lihat semua &rarr;</a>
      </div>
      <div class="table-responsive">
        <table class="table table-sm table-modern align-middle mb-0">
          <thead>
            <tr class="text-muted small">
              <th>Tanggal</th>
              <th>Kategori</th>
              <th>Keterangan</th>
              <th class="text-end">Jumlah</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($transaksiTerbaru)): ?>
              <tr>
                <td colspan="4">
                  <div class="empty-state py-4 text-center text-muted">
                    <i class="bi bi-inbox fs-2 d-block mb-2 text-secondary opacity-50"></i>
                    <p class="mb-0 small">Belum ada transaksi pada periode/filter ini.</p>
                  </div>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($transaksiTerbaru as $t): ?>
                <tr>
                  <td class="text-muted small text-nowrap"><?= formatTanggalSingkat($t['tanggal']) ?></td>
                  <td>
                    <span class="badge bg-light text-dark border fw-normal shadow-sm">
                      <?= htmlspecialchars($t['nama_kategori']) ?>
                    </span>
                  </td>
                  <td class="text-break small"><?= htmlspecialchars($t['keterangan']) ?></td>
                  <td class="text-end text-nowrap fw-bold <?= $t['jenis'] === 'masuk' ? 'text-success' : 'text-danger' ?>">
                    <?= $t['jenis'] === 'masuk' ? '+' : '-' ?>    <?= formatRupiah($t['jumlah']) ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php if (!empty($pengajuanPending)): ?>
      <div class="card p-3 shadow-sm border-0 mt-3 rounded-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h6 class="fw-bold mb-0 text-warning">
            <i class="bi bi-exclamation-circle me-1"></i> Pengajuan Menunggu Persetujuan
          </h6>
          <a href="pengajuan.php?status=pending" class="small text-decoration-none">Lihat semua &rarr;</a>
        </div>
        <div class="table-responsive">
          <table class="table table-sm table-modern align-middle mb-0">
            <thead>
              <tr class="text-muted small">
                <th>Tanggal</th>
                <th>HRD</th>
                <th>Keperluan</th>
                <th class="text-end">Jumlah</th>
                <th class="text-center">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($pengajuanPending as $pj): ?>
                <tr>
                  <td class="text-muted small text-nowrap"><?= formatTanggalSingkat($pj['tanggal_pengajuan']) ?></td>
                  <td class="small text-nowrap fw-semibold"><?= htmlspecialchars($pj['nama_hrd']) ?></td>
                  <td class="text-break small"><?= htmlspecialchars($pj['keperluan']) ?></td>
                  <td class="text-end text-nowrap fw-semibold text-primary"><?= formatRupiah($pj['jumlah']) ?></td>
                  <td class="text-center text-nowrap">
                    <a href="pengajuan.php?status=pending"
                      class="btn btn-sm btn-primary py-1 px-3 rounded-pill btn-hover-bounce shadow-sm"
                      style="font-size: 0.75rem;">
                      Proses
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <div class="col-lg-4">
    <div class="card p-3 shadow-sm border-0 rounded-3 mb-3">
      <h6 class="fw-bold mb-3">
        <i class="bi bi-pie-chart me-1 text-primary"></i> Visualisasi Kas
      </h6>
      <div style="height: 180px; position: relative;">
        <canvas id="kasChart"></canvas>
      </div>
    </div>

    <div class="card p-3 shadow-sm border-0 rounded-3">
      <h6 class="fw-bold mb-3">
        <i class="bi bi-graph-up me-1 text-primary"></i> Ringkasan Sistem
      </h6>
      <div class="small">
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted">Total Transaksi</span>
          <span class="fw-bold"><?= $totalTransaksi ?></span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted">Pengajuan Pending</span>
          <span class="fw-bold text-warning"><?= $totalPending ?></span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted">Pengajuan Disetujui</span>
          <span class="fw-bold text-success"><?= $totalDisetujui ?></span>
        </div>
        <div class="d-flex justify-content-between pt-3 align-items-center">
          <span class="text-muted">Saldo Saat Ini</span>
          <span class="fw-bold text-primary fs-6"><?= formatRupiah($saldo['saldo']) ?></span>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById('kasChart').getContext('2d');
    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Kas Masuk', 'Kas Keluar'],
        datasets: [{
          data: [<?= (float) $saldo['masuk'] ?>, <?= (float) $saldo['keluar'] ?>],
          backgroundColor: ['#38ef7d', '#ef473a'],
          borderWidth: 0,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 12,
              font: { size: 11 }
            }
          }
        },
        cutout: '70%'
      }
    });
  });
</script>

<?php require '../includes/footer.php'; ?>