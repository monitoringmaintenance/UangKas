<?php
session_start();
include '../includes/koneksi.php';

// Validasi akses login & role
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'bendahara' && $_SESSION['role'] != 'admin')) {
    exit("Akses ditolak");
}

// Ambil library Dompdf
require_once '../vendor/autoload.php';
use Dompdf\Dompdf;

// Ambil filter dari URL
$dari = isset($_GET['dari']) ? $_GET['dari'] : date('Y-m-01');
$sampai = isset($_GET['sampai']) ? $_GET['sampai'] : date('Y-m-d');
$kategoriFilter = isset($_GET['kategori_id']) ? $_GET['kategori_id'] : '';
$jenisFilter = isset($_GET['jenis']) ? $_GET['jenis'] : '';

// Query data
$where = array("t.tanggal BETWEEN '$dari' AND '$sampai'");
if ($jenisFilter !== '' && ($jenisFilter == 'masuk' || $jenisFilter == 'keluar')) {
    $where[] = "t.jenis = '$jenisFilter'";
}
if ($kategoriFilter !== '' && is_numeric($kategoriFilter)) {
    $where[] = "t.kategori_id = " . (int) $kategoriFilter;
}
$whereSql = 'WHERE ' . implode(' AND ', $where);

$q = mysqli_query($conn, "
    SELECT t.*, k.nama_kategori, 
           CASE 
               WHEN u.role = 'bendahara' THEN 'Bendahara'
               ELSE COALESCE(u.nama_lengkap, u.username, 'Sistem')
           END AS pencatat
    FROM transaksi_kas t
    JOIN kategori_transaksi k ON k.id = t.kategori_id
    LEFT JOIN users u ON u.id = t.created_by
    $whereSql
    ORDER BY t.tanggal ASC, t.id ASC
");

$transaksi = array();
while ($row = mysqli_fetch_assoc($q)) {
    $transaksi[] = $row;
}

// Hitung total
$totalMasuk = 0;
$totalKeluar = 0;
foreach ($transaksi as $t) {
    if ($t['jenis'] === 'masuk') {
        $totalMasuk += $t['jumlah'];
    } else {
        $totalKeluar += $t['jumlah'];
    }
}

$saldoAwal = function_exists('getSaldoSebelum') ? getSaldoSebelum($conn, $dari) : 0;
$saldoAkhir = $saldoAwal + ($totalMasuk - $totalKeluar);

// Fungsi format tanggal Indonesia
function formatIndo($tanggal)
{
    if (!$tanggal)
        return '-';
    $split = explode('-', $tanggal);
    if (count($split) < 3)
        return $tanggal;
    $bulan = array(
        '01' => 'Januari',
        '02' => 'Februari',
        '03' => 'Maret',
        '04' => 'April',
        '05' => 'Mei',
        '06' => 'Juni',
        '07' => 'Juli',
        '08' => 'Agustus',
        '09' => 'September',
        '10' => 'Oktober',
        '11' => 'November',
        '12' => 'Desember'
    );
    return $split[2] . ' ' . $bulan[$split[1]] . ' ' . $split[0];
}

$periodeText = formatIndo($dari) . ' — ' . formatIndo($sampai);

// Susun HTML agar menyerupai tampilan web
$html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 9pt;
            color: #212529;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            padding: 5px;
        }
        .text-center { text-align: center; }
        .text-end { text-align: right; }
        .fw-bold { font-weight: bold; }
        
        /* Header Rincian Transaksi Kas */
        .report-header {
            margin-bottom: 15px;
        }
        .report-header h3 {
            margin: 0 0 3px 0;
            font-size: 14pt;
            color: #212529;
            letter-spacing: 0.5px;
        }
        .report-header p {
            margin: 0;
            font-size: 9pt;
            color: #6c757d;
        }

        /* Tabel Custom ala Web */
        .table-custom {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1rem;
            color: #212529;
        }
        .table-custom th, .table-custom td {
            padding: 8px 10px;
            vertical-align: middle;
            border: 1px solid #dee2e6;
        }
        .table-custom th {
            background-color: #f8f9fa;
            color: #6c757d;
            font-weight: bold;
            font-size: 8.5pt;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Badge Kategori */
        .badge-kategori {
            background-color: #f8f9fa;
            border: 1px solid #ced4da;
            padding: 3px 8px;
            font-size: 8pt;
            border-radius: 10px;
            color: #495057;
            display: inline-block;
        }
        
        .text-success { color: #198754; }
        .text-danger { color: #dc3545; }
        .text-primary { color: #0d6efd; }
    </style>
</head>
<body>
    <div class="container">
        <div class="report-header">
            <h3>RINCIAN TRANSAKSI KAS</h3>
            <p>Periode: ' . $periodeText . '</p>
        </div>
        
        <table class="table-custom">
            <thead>
                <tr>
                    <th width="30" class="text-center">#</th>
                    <th width="110" class="text-center">TANGGAL</th>
                    <th width="140">KATEGORI</th>
                    <th>KETERANGAN</th>
                    <th width="100">PENCATAT</th>
                    <th width="95" class="text-end">MASUK</th>
                    <th width="95" class="text-end">KELUAR</th>
                </tr>
            </thead>
            <tbody>';

$no = 1;
if (empty($transaksi)) {
    $html .= '<tr><td colspan="7" class="text-center">Tidak ada data transaksi pada periode ini.</td></tr>';
} else {
    foreach ($transaksi as $t) {
        $masukVal = ($t['jenis'] === 'masuk') ? 'Rp ' . number_format($t['jumlah'], 0, ',', '.') : '-';
        $keluarVal = ($t['jenis'] === 'keluar') ? 'Rp ' . number_format($t['jumlah'], 0, ',', '.') : '-';

        $masukClass = ($t['jenis'] === 'masuk') ? 'text-success fw-bold' : 'text-success';
        $keluarClass = ($t['jenis'] === 'keluar') ? 'text-danger fw-bold' : 'text-danger';

        $html .= '<tr>
            <td class="text-center">' . $no++ . '</td>
            <td class="text-center">' . formatIndo($t['tanggal']) . '</td>
            <td><span class="badge-kategori">' . htmlspecialchars($t['nama_kategori']) . '</span></td>
            <td>' . htmlspecialchars($t['keterangan']) . '</td>
            <td>' . htmlspecialchars($t['pencatat']) . '</td>
            <td class="text-end ' . $masukClass . '">' . $masukVal . '</td>
            <td class="text-end ' . $keluarClass . '">' . $keluarVal . '</td>
        </tr>';
    }
}

$html .= '</tbody>
            <tfoot>
                <tr>
                    <td colspan="5" class="text-end fw-bold">TOTAL PERIODE INI</td>
                    <td class="text-end fw-bold text-success">Rp ' . number_format($totalMasuk, 0, ',', '.') . '</td>
                    <td class="text-end fw-bold text-danger">Rp ' . number_format($totalKeluar, 0, ',', '.') . '</td>
                </tr>
                <tr>
                    <td colspan="5" class="text-end fw-bold">SALDO AKHIR</td>
                    <td colspan="2" class="text-end fw-bold text-primary">Rp ' . number_format($saldoAkhir, 0, ',', '.') . '</td>
                </tr>
            </tfoot>
        </table>
    </div>
</body>
</html>';

// Render PDF menggunakan Dompdf
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();

// Output langsung unduh file (Attachment => true)
$dompdf->stream("Rincian_Transaksi_Kas_$dari.pdf", array("Attachment" => true));
exit;