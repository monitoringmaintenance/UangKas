<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'bendahara' && $_SESSION['role'] != 'admin')) {
    header("Location: ../login.php");
    exit;
}

$dari = isset($_GET['dari']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['dari']) ? $_GET['dari'] : date('Y-m-01');
$sampai = isset($_GET['sampai']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['sampai']) ? $_GET['sampai'] : date('Y-m-d');

if ($dari > $sampai) {
    $temp = $dari;
    $dari = $sampai;
    $sampai = $temp;
}

$kategoriFilter = isset($_GET['kategori_id']) ? $_GET['kategori_id'] : '';
$jenisFilter = isset($_GET['jenis']) ? $_GET['jenis'] : '';

$kategoriList = array();
$qk = mysqli_query($conn, "SELECT * FROM kategori_transaksi ORDER BY jenis, nama_kategori");
while ($row = mysqli_fetch_assoc($qk)) {
    $kategoriList[] = $row;
}

$where = array("t.tanggal BETWEEN '$dari' AND '$sampai'");
if ($jenisFilter === 'masuk' || $jenisFilter === 'keluar') {
    $where[] = "t.jenis = '$jenisFilter'";
}
if ($kategoriFilter !== '' && is_numeric($kategoriFilter)) {
    $where[] = "t.kategori_id = " . (int) $kategoriFilter;
}
$whereSql = 'WHERE ' . implode(' AND ', $where);

$transaksi = array();
$q = mysqli_query($conn, "
    SELECT t.*, k.nama_kategori, 
           CASE 
               WHEN u.role = 'bendahara' THEN 'Bendahara'
               ELSE COALESCE(u.nama_lengkap, u.username, 'Sistem')
           END AS pencatat
    FROM transaksi_kas t
    JOIN kategori_transaksi k ON k.id = t.kategori_id
    LEFT JOIN users u ON u.id = t.created_by
    $whereSql
    ORDER BY t.tanggal ASC, t.id ASC
");
while ($row = mysqli_fetch_assoc($q)) {
    $transaksi[] = $row;
}

$totalMasuk = 0;
$totalKeluar = 0;

foreach ($transaksi as $t) {
    if ($t['jenis'] === 'masuk') {
        $totalMasuk += $t['jumlah'];
    } else {
        $totalKeluar += $t['jumlah'];
    }
}

$saldoAwal = function_exists('getSaldoSebelum') ? getSaldoSebelum($conn, $dari) : 0;
$saldoAkhir = $saldoAwal + ($totalMasuk - $totalKeluar);

$pageTitle = 'Laporan Kas';
require '../includes/header.php';
?>

<style>
    .card-stat {
        border: none;
        border-radius: 14px;
        color: #fff;
        position: relative;
        overflow: hidden;
        transition: transform 0.3s ease;
    }

    .card-stat:hover {
        transform: translateY(-4px);
    }

    .card-stat .stat-icon {
        position: absolute;
        right: 15px;
        bottom: 10px;
        font-size: 3.5rem;
        opacity: 0.2;
    }

    .card-stat .stat-label {
        font-size: 0.85rem;
        font-weight: 500;
        text-transform: uppercase;
        opacity: 0.9;
    }

    .card-stat .stat-value {
        font-size: 1.4rem;
        font-weight: 700;
        margin-top: 4px;
    }

    .bg-saldo {
        background: linear-gradient(135deg, #0d6efd, #0b5ed7);
    }

    .bg-masuk {
        background: linear-gradient(135deg, #198754, #157347);
    }

    .bg-keluar {
        background: linear-gradient(135deg, #dc3545, #bb2d3b);
    }

    .bg-akhir {
        background: linear-gradient(135deg, #6f42c1, #d63384);
    }

    .card-modern {
        border: none;
        border-radius: 14px;
        background: #ffffff;
    }

    @media print {
        @page {
            size: A4 landscape;
            margin: 1cm;
        }

        .no-print,
        nav,
        header,
        footer,
        sidebar,
        .sidebar,
        .navbar {
            display: none !important;
        }

        body {
            background-color: #fff !important;
            color: #000 !important;
            font-size: 11pt;
            font-family: Arial, sans-serif;
            margin: 0 !important;
            padding: 0 !important;
        }

        .card {
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
            background: transparent !important;
        }

        table {
            width: 100% !important;
            border-collapse: collapse !important;
        }

        th,
        td {
            border: 1px solid #000 !important;
            padding: 8px 10px !important;
            color: #000 !important;
        }

        th {
            background-color: #f2f2f2 !important;
            text-align: center;
        }
    }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="mb-0 fw-bold"><i class="bi bi-bar-chart-fill me-2 text-primary"></i> Laporan Kas Perusahaan</h4>
        <small class="text-muted">Pantau rekapitulasi kas masuk, kas keluar, dan ringkasan saldo</small>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
        <div class="card card-stat bg-saldo p-3 shadow-sm">
            <i class="bi bi-wallet2 stat-icon"></i>
            <div class="stat-label">Saldo Awal</div>
            <div class="stat-value">
                <?= function_exists('formatRupiah') ? formatRupiah($saldoAwal) : 'Rp ' . number_format($saldoAwal, 0, ',', '.') ?>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card card-stat bg-masuk p-3 shadow-sm">
            <i class="bi bi-arrow-down-circle stat-icon"></i>
            <div class="stat-label">Total Masuk</div>
            <div class="stat-value">
                <?= function_exists('formatRupiah') ? formatRupiah($totalMasuk) : 'Rp ' . number_format($totalMasuk, 0, ',', '.') ?>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card card-stat bg-keluar p-3 shadow-sm">
            <i class="bi bi-arrow-up-circle stat-icon"></i>
            <div class="stat-label">Total Keluar</div>
            <div class="stat-value">
                <?= function_exists('formatRupiah') ? formatRupiah($totalKeluar) : 'Rp ' . number_format($totalKeluar, 0, ',', '.') ?>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card card-stat bg-akhir p-3 shadow-sm">
            <i class="bi bi-graph-up-arrow stat-icon"></i>
            <div class="stat-label">Saldo Akhir</div>
            <div class="stat-value">
                <?= function_exists('formatRupiah') ? formatRupiah($saldoAkhir) : 'Rp ' . number_format($saldoAkhir, 0, ',', '.') ?>
            </div>
        </div>
    </div>
</div>

<!-- FILTER DIUPDATE MENJADI INPUT GROUP YANG SINKRON -->
<div class="card card-modern p-4 mb-4 no-print shadow-sm">
    <div class="fw-bold mb-3 small text-secondary d-flex align-items-center gap-1">
        <i class="bi bi-funnel-fill text-primary"></i> Filter Laporan Transaksi
    </div>
    <form method="GET" class="row g-3">
        <!-- Dari Tanggal -->
        <div class="col-lg-3 col-md-6">
            <label class="form-label small text-muted mb-1 fw-semibold">Dari Tanggal</label>
            <div class="input-group input-group-sm">
                <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
                <input type="date" name="dari" value="<?= htmlspecialchars($dari, ENT_QUOTES, 'UTF-8') ?>"
                    class="form-control">
            </div>
        </div>

        <!-- Sampai Tanggal -->
        <div class="col-lg-3 col-md-6">
            <label class="form-label small text-muted mb-1 fw-semibold">Sampai Tanggal</label>
            <div class="input-group input-group-sm">
                <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
                <input type="date" name="sampai" value="<?= htmlspecialchars($sampai, ENT_QUOTES, 'UTF-8') ?>"
                    class="form-control">
            </div>
        </div>

        <!-- Jenis Transaksi -->
        <div class="col-lg-3 col-md-6">
            <label class="form-label small text-muted mb-1 fw-semibold">Jenis Transaksi</label>
            <div class="input-group input-group-sm">
                <select name="jenis" class="form-select">
                    <option value="">Semua Jenis</option>
                    <option value="masuk" <?= $jenisFilter === 'masuk' ? 'selected' : '' ?>>Kas Masuk</option>
                    <option value="keluar" <?= $jenisFilter === 'keluar' ? 'selected' : '' ?>>Kas Keluar</option>
                </select>
                <span class="input-group-text"><i class="bi bi-chevron-down"></i></span>
            </div>
        </div>

        <!-- Kategori -->
        <div class="col-lg-3 col-md-6">
            <label class="form-label small text-muted mb-1 fw-semibold">Kategori</label>
            <div class="input-group input-group-sm">
                <select name="kategori_id" class="form-select">
                    <option value="">Semua Kategori</option>
                    <?php foreach ($kategoriList as $k): ?>
                        <option value="<?= $k['id'] ?>" <?= (string) $kategoriFilter === (string) $k['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($k['nama_kategori'], ENT_QUOTES, 'UTF-8') ?> (<?= ucfirst($k['jenis']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <span class="input-group-text"><i class="bi bi-chevron-down"></i></span>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <div class="col-12 d-flex justify-content-end gap-2 pt-2 border-top">
            <a href="laporan.php" class="btn btn-sm btn-outline-secondary px-3 rounded-3"><i
                    class="bi bi-arrow-counterclockwise me-1"></i> Reset</a>
            <button type="submit" class="btn btn-sm btn-primary px-4 rounded-3 fw-semibold"><i
                    class="bi bi-funnel me-1"></i> Tampilkan</button>
        </div>
    </form>
</div>

<!-- TABEL -->
<div class="card card-modern p-4 shadow-sm">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h5 class="fw-bold mb-0 text-dark">RINCIAN TRANSAKSI KAS</h5>
            <div class="text-muted small no-print">
                Periode: <?= date('d/m/Y', strtotime($dari)) ?> &mdash; <?= date('d/m/Y', strtotime($sampai)) ?>
            </div>
        </div>
        <div class="no-print">
            <a href="download_pdf.php?dari=<?= $dari ?>&sampai=<?= $sampai ?>&jenis=<?= $jenisFilter ?>&kategori_id=<?= $kategoriFilter ?>"
                class="btn btn-primary btn-sm rounded-3 fw-semibold">
                <i class="bi bi-download me-1"></i> Cetak / Simpan PDF
            </a>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover align-middle mb-0">
            <thead class="table-light">
                <tr class="text-center">
                    <th style="width:40px">No</th>
                    <th style="width:130px">Tanggal</th>
                    <th style="width:160px">Kategori</th>
                    <th>Keterangan</th>
                    <th style="width:140px">Pencatat</th>
                    <th style="width:140px" class="text-end">Masuk</th>
                    <th style="width:140px" class="text-end">Keluar</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($transaksi)): ?>
                    <tr>
                        <td colspan="7" class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1 opacity-50 d-block mb-2"></i>
                            <h6 class="fw-bold">Tidak Ada Transaksi</h6>
                            <p class="mb-0 small">Tidak ada transaksi pada periode tersebut.</p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($transaksi as $i => $t): ?>
                        <tr>
                            <td class="text-center text-muted small"><?= $i + 1 ?></td>
                            <td class="text-nowrap"><?= date('d/m/Y', strtotime($t['tanggal'])) ?></td>
                            <td><span
                                    class="badge bg-light text-dark border fw-normal px-2 py-1"><?= htmlspecialchars($t['nama_kategori'], ENT_QUOTES, 'UTF-8') ?></span>
                            </td>
                            <td class="text-break"><?= htmlspecialchars($t['keterangan'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td class="text-nowrap"><?= htmlspecialchars($t['pencatat'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td class="text-end text-success fw-semibold">
                                <?= $t['jenis'] === 'masuk' ? number_format($t['jumlah'], 0, ',', '.') : '-' ?>
                            </td>
                            <td class="text-end text-danger fw-semibold">
                                <?= $t['jenis'] === 'keluar' ? number_format($t['jumlah'], 0, ',', '.') : '-' ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
            <?php if (!empty($transaksi)): ?>
                <tfoot class="table-light">
                    <tr>
                        <td colspan="5" class="text-end fw-bold">TOTAL PERIODE INI</td>
                        <td class="text-end text-success fw-bold"><?= number_format($totalMasuk, 0, ',', '.') ?></td>
                        <td class="text-end text-danger fw-bold"><?= number_format($totalKeluar, 0, ',', '.') ?></td>
                    </tr>
                    <tr>
                        <td colspan="5" class="text-end fw-bold">SALDO AKHIR</td>
                        <td colspan="2" class="text-end fw-bold text-primary fs-6">
                            <?= number_format($saldoAkhir, 0, ',', '.') ?>
                        </td>
                    </tr>
                </tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>

<?php require '../includes/footer.php'; ?>