<?php
$conn = mysqli_connect("localhost", "root", "", "kas_pt");

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

function formatRupiah($angka)
{
    return "Rp " . number_format($angka, 0, ",", ".");
}

function formatTanggal($tanggal)
{
    $bulan = array(
        1 => "Januari",
        "Februari",
        "Maret",
        "April",
        "Mei",
        "Juni",
        "Juli",
        "Agustus",
        "September",
        "Oktober",
        "November",
        "Desember"
    );
    $ts = strtotime($tanggal);
    return date("d", $ts) . " " . $bulan[(int) date("n", $ts)] . " " . date("Y", $ts);
}

function formatTanggalSingkat($tanggal)
{
    $bulan = array(
        1 => "Jan",
        "Feb",
        "Mar",
        "Apr",
        "Mei",
        "Jun",
        "Jul",
        "Agu",
        "Sep",
        "Okt",
        "Nov",
        "Des"
    );
    $ts = strtotime($tanggal);
    return date("d", $ts) . " " . $bulan[(int) date("n", $ts)] . " " . date("Y", $ts);
}

function formatTanggalWaktu($tanggal)
{
    return date("d M Y H:i", strtotime($tanggal));
}

function badgeStatus($status)
{
    if ($status == "pending") {
        return '<span class="badge bg-soft-warning"><i class="bi bi-clock"></i> Menunggu</span>';
    } elseif ($status == "disetujui") {
        return '<span class="badge bg-soft-success"><i class="bi bi-check-circle"></i> Disetujui</span>';
    } elseif ($status == "ditolak") {
        return '<span class="badge bg-soft-danger"><i class="bi bi-x-circle"></i> Ditolak</span>';
    }
    return '<span class="badge bg-secondary">' . $status . '</span>';
}

function badgeJenis($jenis)
{
    if ($jenis == "masuk") {
        return '<span class="badge bg-soft-success"><i class="bi bi-arrow-down"></i> Masuk</span>';
    }
    return '<span class="badge bg-soft-danger"><i class="bi bi-arrow-up"></i> Keluar</span>';
}

function getSaldoKas($conn, $dari = null, $sampai = null)
{
    if ($dari && $sampai) {
        $sql = "SELECT
                    SUM(CASE WHEN jenis='masuk' THEN jumlah ELSE 0 END) AS total_masuk,
                    SUM(CASE WHEN jenis='keluar' THEN jumlah ELSE 0 END) AS total_keluar
                FROM transaksi_kas WHERE tanggal BETWEEN '$dari' AND '$sampai'";
    } else {
        $sql = "SELECT
                    SUM(CASE WHEN jenis='masuk' THEN jumlah ELSE 0 END) AS total_masuk,
                    SUM(CASE WHEN jenis='keluar' THEN jumlah ELSE 0 END) AS total_keluar
                FROM transaksi_kas";
    }
    $q = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($q);
    $masuk = $row['total_masuk'] ? $row['total_masuk'] : 0;
    $keluar = $row['total_keluar'] ? $row['total_keluar'] : 0;
    return array(
        "masuk" => $masuk,
        "keluar" => $keluar,
        "saldo" => $masuk - $keluar,
    );
}

function getSaldoSebelum($conn, $tanggal)
{
    $sql = "SELECT
                COALESCE(SUM(CASE WHEN jenis='masuk' THEN jumlah ELSE 0 END),0) -
                COALESCE(SUM(CASE WHEN jenis='keluar' THEN jumlah ELSE 0 END),0) AS saldo
            FROM transaksi_kas WHERE tanggal < '$tanggal'";
    $q = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($q);
    return $row['saldo'] ? $row['saldo'] : 0;
}

function getPeriodPresets()
{
    return array(
        "hini" => array("label" => "Hari Ini", "dari" => date("Y-m-d"), "sampai" => date("Y-m-d")),
        "7hari" => array("label" => "7 Hari Terakhir", "dari" => date("Y-m-d", strtotime("-6 days")), "sampai" => date("Y-m-d")),
        "bulanini" => array("label" => "Bulan Ini", "dari" => date("Y-m-01"), "sampai" => date("Y-m-d")),
        "bulanlalu" => array("label" => "Bulan Lalu", "dari" => date("Y-m-01", strtotime("-1 month")), "sampai" => date("Y-m-t", strtotime("-1 month"))),
        "3bulan" => array("label" => "3 Bulan Terakhir", "dari" => date("Y-m-d", strtotime("-3 months")), "sampai" => date("Y-m-d")),
        "tahunini" => array("label" => "Tahun Ini", "dari" => date("Y-01-01"), "sampai" => date("Y-m-d")),
    );
}

function renderPagination($currentPage, $totalItems, $perPage, $queryParams = array())
{
    $totalPages = max(1, (int) ceil($totalItems / $perPage));
    $currentPage = max(1, min($currentPage, $totalPages));
    if ($totalPages <= 1)
        return '';

    $query = $queryParams;
    $html = '<nav class="d-flex justify-content-between align-items-center mt-3">';
    $html .= '<small class="text-muted">Menampilkan ' . (($currentPage - 1) * $perPage + 1) . '&ndash;' . min($currentPage * $perPage, $totalItems) . ' dari ' . $totalItems . ' data</small>';
    $html .= '<ul class="pagination pagination-sm mb-0">';

    $query['page'] = max(1, $currentPage - 1);
    $prevDisabled = $currentPage <= 1 ? ' disabled' : '';
    $html .= '<li class="page-item' . $prevDisabled . '"><a class="page-link" href="?' . http_build_query($query) . '"><i class="bi bi-chevron-left"></i></a></li>';

    $range = 2;
    for ($i = max(1, $currentPage - $range); $i <= min($totalPages, $currentPage + $range); $i++) {
        $query['page'] = $i;
        $active = $i === $currentPage ? ' active' : '';
        $html .= '<li class="page-item' . $active . '"><a class="page-link" href="?' . http_build_query($query) . '">' . $i . '</a></li>';
    }

    $query['page'] = min($totalPages, $currentPage + 1);
    $nextDisabled = $currentPage >= $totalPages ? ' disabled' : '';
    $html .= '<li class="page-item' . $nextDisabled . '"><a class="page-link" href="?' . http_build_query($query) . '"><i class="bi bi-chevron-right"></i></a></li>';

    $html .= '</ul></nav>';
    return $html;
}
