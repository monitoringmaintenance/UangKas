</main>
</div>

<div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style="max-width:420px;">
    <div class="modal-content">
      <div class="modal-header border-0 pb-0">
        <h6 class="modal-title fw-bold" id="confirmModalTitle"><i class="bi bi-question-circle"
            style="color:var(--accent)"></i> Konfirmasi</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body">
        <p id="confirmModalBody" class="mb-0" style="font-size:0.9rem;color:var(--text-secondary);"></p>
      </div>
      <div class="modal-footer border-0 pt-0">
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="confirmModalBtn" class="btn btn-danger btn-sm"><i class="bi bi-check-lg"></i> Ya, Lanjutkan</a>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Toast auto-dismiss
    var toast = document.getElementById('flashToast');
    if (toast) {
      setTimeout(function () {
        var t = toast.querySelector('.custom-toast');
        if (t) {
          t.style.animation = 'slideInRight 0.3s ease-in reverse forwards';
          setTimeout(function () { toast.remove(); }, 350);
        }
      }, 4000);
    }

    // Confirmation modal
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.preventDefault();
        var msg = this.getAttribute('data-confirm') || 'Apakah Anda yakin?';
        var title = this.getAttribute('data-confirm-title') || 'Konfirmasi';
        var btnClass = this.getAttribute('data-confirm-btn') || 'btn-danger';
        var confirmForm = this.getAttribute('data-confirm-form');

        document.getElementById('confirmModalBody').textContent = msg;
        document.getElementById('confirmModalTitle').innerHTML = '<i class="bi bi-question-circle" style="color:var(--accent)"></i> ' + title;
        var btn = document.getElementById('confirmModalBtn');
        btn.className = 'btn ' + btnClass + ' btn-sm';

        if (confirmForm) {
          var sourceForm = document.getElementById(confirmForm);
          if (sourceForm) {
            btn.onclick = function () { sourceForm.submit(); return false; };
            btn.removeAttribute('href');
          }
        } else {
          var href = this.getAttribute('href') || '#';
          btn.href = href;
          btn.onclick = null;
        }

        var modal = new bootstrap.Modal(document.getElementById('confirmModal'));
        modal.show();
      });
    });

    // Sidebar toggle (mobile)
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebarOverlay');
    var closeBtn = document.getElementById('sidebarClose');

    function openSidebar() { sidebar.classList.add('show'); overlay.classList.add('show'); document.body.style.overflow = 'hidden'; }
    function closeSidebar() { sidebar.classList.remove('show'); overlay.classList.remove('show'); document.body.style.overflow = ''; }

    var toggleBtn = document.getElementById('sidebarToggle');
    if (toggleBtn) toggleBtn.addEventListener('click', openSidebar);
    if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
    if (overlay) overlay.addEventListener('click', closeSidebar);

    // Keyboard: Escape closes sidebar
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && sidebar.classList.contains('show')) closeSidebar();
    });

    // Page content animation
    var mainContent = document.querySelector('.main-content');
    if (mainContent) mainContent.style.opacity = '1';
  });
</script>
</body>

</html>