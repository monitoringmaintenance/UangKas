<?php
$pageTitle = isset($pageTitle) ? $pageTitle : 'Kas PT MNC';
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$isSub = preg_match('#/(admin|bendahara|hrd)/#', $_SERVER['SCRIPT_NAME']);
$base = $isSub ? '../' : '';
$currentPage = basename($_SERVER['SCRIPT_NAME']);
$nama = isset($_SESSION['nama_lengkap']) ? $_SESSION['nama_lengkap'] : '';
$initials = '';

if ($nama) {
  $parts = explode(' ', $nama);
  $initials = strtoupper(substr($parts[0], 0, 1));
  if (count($parts) > 1) {
    $initials .= strtoupper(substr(end($parts), 0, 1));
  }
}

setlocale(LC_TIME, 'id_ID.utf8', 'id_ID', 'indonesian');
$tanggalHariIni = date('d M Y');
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?> | Aplikasi Kas PT MNC</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <link rel="stylesheet" href="<?= $base ?>assets/style.css">

  <style>
    body {
      background-color: #f8f9fa;
      margin: 0;
      padding: 0;
    }

    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #ffffff;
      border-right: 1px solid #e5e7eb;
      display: flex;
      flex-direction: column;
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      z-index: 1030;
      transition: all 0.3s ease;
    }

    .sidebar-header {
      height: 70px;
      padding: 0 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #e5e7eb;
    }

    .sidebar-brand-wrapper {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none !important;
    }

    .sidebar-brand-logo {
      height: 36px;
      width: auto;
      object-fit: contain;
    }

    .sidebar-brand-text {
      font-size: 1.1rem;
      font-weight: 700;
      color: #1f2937;
    }

    .main-wrapper {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      min-width: 0;
    }

    .top-navbar {
      height: 70px;
      background: #ffffff;
      border-bottom: 1px solid #e5e7eb;
      padding: 0 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 1020;
    }

    .content-body {
      padding: 24px;
      flex: 1;
    }

    /* Tambahan style untuk Mobile Overlay Sidebar */
    .sidebar-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(2px);
      z-index: 1025;
      display: none;
      transition: all 0.3s ease;
    }

    .sidebar-overlay.show {
      display: block;
    }

    @media (max-width: 991.98px) {
      .sidebar {
        margin-left: -260px;
      }

      .sidebar.show {
        margin-left: 0;
      }

      .main-wrapper {
        margin-left: 0;
      }
    }

    /* Styles untuk Custom Modal Logout */
    .logout-modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      backdrop-filter: blur(4px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      opacity: 0;
      visibility: hidden;
      transition: all 0.25s ease-in-out;
    }

    .logout-modal-overlay.active {
      opacity: 1;
      visibility: visible;
    }

    .logout-modal-card {
      background: #ffffff;
      padding: 28px 24px;
      border-radius: 16px;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
      text-align: center;
      max-width: 360px;
      width: 90%;
      transform: scale(0.85);
      transition: transform 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    .logout-modal-overlay.active .logout-modal-card {
      transform: scale(1);
    }

    .logout-icon {
      width: 60px;
      height: 60px;
      background: #fee2e2;
      color: #dc2626;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 16px;
      font-size: 1.75rem;
    }
  </style>
</head>

<body>

  <div class="app-layout">
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-header">
        <a href="<?= $base ?>index.php" class="sidebar-brand-wrapper">
          <img src="<?= $base ?>assets/mnc1.jpg" alt="Logo PT MNC" class="sidebar-brand-logo">
          <span class="sidebar-brand-text">Kas PT MNC</span>
        </a>
        <button class="btn-close d-lg-none" id="sidebarClose" aria-label="Tutup menu"></button>
      </div>

      <nav class="sidebar-nav p-3">
        <?php if ($role == 'admin'): ?>
          <div class="sidebar-section-label text-uppercase text-muted small fw-bold mb-2">Menu Utama</div>
          <a class="sidebar-link <?= $currentPage == 'dashboard.php' ? 'active' : '' ?>"
            href="<?= $base ?>admin/dashboard.php">
            <i class="bi bi-grid-1x2 me-2"></i> Dashboard
          </a>
          <a class="sidebar-link <?= ($currentPage == 'users.php' || $currentPage == 'user_form.php') ? 'active' : '' ?>"
            href="<?= $base ?>admin/users.php">
            <i class="bi bi-people me-2"></i> Kelola User
          </a>
          <a class="sidebar-link <?= $currentPage == 'kategori.php' ? 'active' : '' ?>"
            href="<?= $base ?>admin/kategori.php">
            <i class="bi bi-tags me-2"></i> Kategori
          </a>
          <a class="sidebar-link <?= $currentPage == 'transaksi.php' ? 'active' : '' ?>"
            href="<?= $base ?>admin/transaksi.php">
            <i class="bi bi-cash-stack me-2"></i> Transaksi
          </a>
          <div class="sidebar-section-label text-uppercase text-muted small fw-bold mt-3 mb-2">Laporan</div>
          <a class="sidebar-link <?= $currentPage == 'laporan.php' ? 'active' : '' ?>"
            href="<?= $base ?>bendahara/laporan.php">
            <i class="bi bi-bar-chart-line me-2"></i> Laporan Kas
          </a>
        <?php endif; ?>

        <?php if ($role == 'bendahara'): ?>
          <div class="sidebar-section-label text-uppercase text-muted small fw-bold mb-2">Menu Utama</div>
          <a class="sidebar-link <?= $currentPage == 'dashboard.php' ? 'active' : '' ?>"
            href="<?= $base ?>bendahara/dashboard.php">
            <i class="bi bi-grid-1x2 me-2"></i> Dashboard
          </a>
          <a class="sidebar-link <?= ($currentPage == 'transaksi.php' || $currentPage == 'transaksi_form.php') ? 'active' : '' ?>"
            href="<?= $base ?>bendahara/transaksi.php">
            <i class="bi bi-cash-stack me-2"></i> Transaksi
          </a>
          <a class="sidebar-link <?= $currentPage == 'pengajuan.php' ? 'active' : '' ?>"
            href="<?= $base ?>bendahara/pengajuan.php">
            <i class="bi bi-inbox me-2"></i> Pengajuan Dana
          </a>
          <div class="sidebar-section-label text-uppercase text-muted small fw-bold mt-3 mb-2">Laporan</div>
          <a class="sidebar-link <?= $currentPage == 'laporan.php' ? 'active' : '' ?>"
            href="<?= $base ?>bendahara/laporan.php">
            <i class="bi bi-bar-chart-line me-2"></i> Laporan Kas
          </a>
        <?php endif; ?>

        <?php if ($role == 'hrd'): ?>
          <div class="sidebar-section-label text-uppercase text-muted small fw-bold mb-2">Menu Utama</div>
          <a class="sidebar-link <?= $currentPage == 'dashboard.php' ? 'active' : '' ?>"
            href="<?= $base ?>hrd/dashboard.php">
            <i class="bi bi-grid-1x2 me-2"></i> Dashboard
          </a>
          <a class="sidebar-link <?= ($currentPage == 'pengajuan.php' || $currentPage == 'pengajuan_form.php') ? 'active' : '' ?>"
            href="<?= $base ?>hrd/pengajuan.php">
            <i class="bi bi-file-earmark-text me-2"></i> Pengajuan Dana
          </a>
        <?php endif; ?>
      </nav>
    </aside>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="main-wrapper">
      <header class="top-navbar no-print">
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-outline-secondary btn-sm d-lg-none" id="sidebarToggle">
            <i class="bi bi-list fs-5"></i>
          </button>

          <div>
            <h6 class="mb-0 fw-bold text-dark">Selamat Datang, <?= htmlspecialchars($nama) ?> 👋</h6>
            <small class="text-muted d-none d-sm-inline" style="font-size: 0.78rem;">
              <i class="bi bi-calendar3 me-1"></i><?= $tanggalHariIni ?>
            </small>
          </div>
        </div>

        <div class="d-flex align-items-center gap-3">
          <!-- Profil User & Edit Profil Link -->
          <a href="<?= $base ?>profil.php" class="d-flex align-items-center gap-2 pe-3 border-end text-decoration-none">
            <div
              class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm"
              style="width: 38px; height: 38px; font-size: 0.95rem;">
              <?= $initials ?>
            </div>
            <div class="d-none d-md-block text-end">
              <div class="fw-bold lh-1 small mb-1 text-dark"><?= htmlspecialchars($nama) ?></div>
              <small class="text-muted text-capitalize lh-1 d-block" style="font-size: 0.75rem;">
                <i class="bi bi-person-badge me-1"></i><?= htmlspecialchars($role) ?>
              </small>
            </div>
          </a>

          <!-- Tombol Logout Modal -->
          <button type="button" onclick="openLogoutModal()"
            class="btn btn-sm btn-outline-danger px-3 d-flex align-items-center gap-1">
            <i class="bi bi-box-arrow-right"></i>
            <span class="d-none d-sm-inline">Logout</span>
          </button>
        </div>
      </header>

      <main class="content-body">
        <?php if (!empty($_SESSION['flash'])): ?>
          <?php
          $flash = $_SESSION['flash'];
          unset($_SESSION['flash']);
          $type = $flash['type'];
          $toastClass = $type == 'success' ? 'toast-success' : ($type == 'error' ? 'toast-error' : 'toast-info');
          $icon = $type == 'success' ? 'bi-check-circle-fill' : ($type == 'error' ? 'bi-exclamation-triangle-fill' : 'bi-info-circle-fill');
          ?>
          <div class="toast-container mb-3" id="flashToast">
            <div class="custom-toast <?= $toastClass ?>" onclick="this.parentElement.remove()">
              <i class="bi <?= $icon ?>"></i>
              <span><?= htmlspecialchars($flash['message']) ?></span>
              <button class="toast-close" onclick="event.stopPropagation(); this.parentElement.remove()">&times;</button>
            </div>
          </div>
        <?php endif; ?>

        <!-- Custom Logout Modal Structure -->
        <div class="logout-modal-overlay" id="logoutModal">
          <div class="logout-modal-card">
            <div class="logout-icon">
              <i class="bi bi-box-arrow-right"></i>
            </div>
            <h5 class="fw-bold mb-2">Konfirmasi Logout</h5>
            <p class="text-muted small mb-4">Apakah Anda yakin ingin keluar dari sistem?</p>
            <div class="d-flex gap-2 justify-content-center">
              <button type="button" class="btn btn-light px-4 fw-medium" onclick="closeLogoutModal()">Batal</button>
              <a href="<?= $base ?>logout.php" class="btn btn-danger px-4 fw-medium">Ya, Keluar</a>
            </div>
          </div>
        </div>

        <script>
          // Fungsi pengendali Logout Modal
          function openLogoutModal() {
            document.getElementById('logoutModal').classList.add('active');
          }

          function closeLogoutModal() {
            document.getElementById('logoutModal').classList.remove('active');
          }

          // Event listener untuk menutup modal jika background diklik
          document.getElementById('logoutModal').addEventListener('click', function (e) {
            if (e.target === this) {
              closeLogoutModal();
            }
          });

          // Toggle Sidebar Mobile
          const sidebar = document.getElementById('sidebar');
          const sidebarToggle = document.getElementById('sidebarToggle');
          const sidebarClose = document.getElementById('sidebarClose');
          const sidebarOverlay = document.getElementById('sidebarOverlay');

          if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function () {
              sidebar.classList.add('show');
              if (sidebarOverlay) sidebarOverlay.classList.add('show');
            });
          }

          if (sidebarClose) {
            sidebarClose.addEventListener('click', function () {
              sidebar.classList.remove('show');
              if (sidebarOverlay) sidebarOverlay.classList.remove('show');
            });
          }

          if (sidebarOverlay) {
            sidebarOverlay.addEventListener('click', function () {
              sidebar.classList.remove('show');
              sidebarOverlay.classList.remove('show');
            });
          }
        </script>
</body>

</html>