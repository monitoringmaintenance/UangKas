<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'hrd') {
  header("Location: ../login.php");
  exit;
}

$error = '';
$data = array('tanggal_pengajuan' => date('Y-m-d'), 'keperluan' => '', 'jumlah' => '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $tanggal = trim($_POST['tanggal_pengajuan'] ?? '');
  $keperluan = trim($_POST['keperluan'] ?? '');
  $jumlah_raw = $_POST['jumlah'] ?? '';

  // Membersihkan format pemisah ribuan (titik/koma)
  $jumlah = preg_replace('/[^0-9]/', '', $jumlah_raw);

  if ($tanggal === '' || $keperluan === '' || $jumlah === '') {
    $error = 'Semua field wajib diisi.';
  } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
    $error = 'Format tanggal tidak valid.';
  } elseif (!is_numeric($jumlah) || (float) $jumlah <= 0) {
    $error = 'Jumlah harus berupa angka lebih dari 0.';
  } elseif (mb_strlen($keperluan) < 5) {
    $error = 'Keperluan minimal 5 karakter.';
  } else {
    $uid = (int) $_SESSION['user_id'];

    // Menggunakan Prepared Statement untuk keamanan SQL Injection
    $stmt = mysqli_prepare($conn, "INSERT INTO pengajuan_dana (tanggal_pengajuan, hrd_id, keperluan, jumlah) VALUES (?, ?, ?, ?)");
    if ($stmt) {
      mysqli_stmt_bind_param($stmt, "siss", $tanggal, $uid, $keperluan, $jumlah);
      if (mysqli_stmt_execute($stmt)) {
        $_SESSION['flash'] = array('type' => 'success', 'message' => 'Pengajuan dana berhasil dikirim, menunggu persetujuan bendahara.');
        mysqli_stmt_close($stmt);
        header('Location: pengajuan.php');
        exit;
      } else {
        $error = 'Gagal menyimpan pengajuan: ' . mysqli_error($conn);
      }
      mysqli_stmt_close($stmt);
    } else {
      $error = 'Terjadi kesalahan pada sistem database.';
    }
  }
  $data = array('tanggal_pengajuan' => $tanggal, 'keperluan' => $keperluan, 'jumlah' => $jumlah_raw);
}

$pageTitle = 'Ajukan Dana Baru';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(15px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .btn-hover-bounce {
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .card-modern {
    border: none;
    border-radius: 14px;
    background: #ffffff;
  }

  .btn-primary {
    background-color: #3867d6;
    border-color: #3867d6;
  }

  .btn-primary:hover {
    background-color: #2b5797;
    border-color: #2b5797;
  }
</style>

<div class="page-header mb-4 animate-fade-up">
  <h4 class="mb-0 fw-bold"><i class="bi bi-file-earmark-plus me-2 text-primary"></i> Ajukan Dana Baru</h4>
  <small class="text-muted">Isi formulir berikut untuk mengajukan dana operasional HRD</small>
</div>

<div class="row g-4">
  <div class="col-lg-8">
    <div class="card card-modern p-4 shadow-sm animate-fade-up">
      <?php if ($error): ?>
        <div class="alert alert-danger py-2 d-flex align-items-center gap-2 rounded-3 mb-3">
          <i class="bi bi-exclamation-triangle-fill flex-shrink-0"></i>
          <div><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        </div>
      <?php endif; ?>

      <form method="POST" id="pengajuanForm">
        <div class="mb-3">
          <label class="form-label fw-semibold">Tanggal Pengajuan</label>
          <input type="date" name="tanggal_pengajuan" class="form-control rounded-3"
            value="<?= htmlspecialchars($data['tanggal_pengajuan'], ENT_QUOTES, 'UTF-8') ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold">Keperluan</label>
          <textarea name="keperluan" class="form-control rounded-3" rows="3"
            placeholder="Contoh: Reimburse biaya perjalanan dinas karyawan" required
            minlength="5"><?= htmlspecialchars($data['keperluan'], ENT_QUOTES, 'UTF-8') ?></textarea>
          <div class="form-text">Jelaskan keperluan pengajuan dana secara rinci.</div>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold">Jumlah yang Diajukan (Rp)</label>
          <input type="text" name="jumlah" id="jumlahInput" class="form-control rounded-3"
            value="<?= htmlspecialchars($data['jumlah'], ENT_QUOTES, 'UTF-8') ?>" placeholder="0" required
            oninput="formatRupiahInput(this)">
        </div>

        <div
          class="alert alert-info small d-flex align-items-center gap-2 mb-4 rounded-3 border-0 bg-opacity-10 bg-info text-info">
          <i class="bi bi-info-circle fs-6 flex-shrink-0"></i>
          <div>Pengajuan akan direview oleh Bendahara. Kamu bisa memantau statusnya secara realtime di halaman Pengajuan
            Dana.</div>
        </div>

        <div class="d-flex gap-2">
          <button type="submit" class="btn btn-primary rounded-3 btn-hover-bounce fw-semibold px-4" id="submitBtn">
            <i class="bi bi-send-fill me-1"></i> Kirim Pengajuan
          </button>
          <a href="pengajuan.php" class="btn btn-outline-secondary rounded-3 btn-hover-bounce">Batal</a>
        </div>
      </form>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card card-modern p-4 shadow-sm animate-fade-up">
      <h6 class="fw-bold mb-3 text-dark"><i class="bi bi-info-circle me-1 text-primary"></i> Alur Pengajuan Dana</h6>
      <div class="small">
        <div class="d-flex align-items-start gap-3 mb-3">
          <div class="rounded-circle bg-primary bg-opacity-10 p-2 flex-shrink-0 text-primary fw-bold"
            style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
            1
          </div>
          <div>
            <strong class="text-dark">Isi Formulir</strong>
            <p class="text-muted mb-0">Lengkapi data keperluan dan jumlah nominal dana dengan benar.</p>
          </div>
        </div>
        <div class="d-flex align-items-start gap-3 mb-3">
          <div class="rounded-circle bg-warning bg-opacity-10 p-2 flex-shrink-0 text-warning fw-bold"
            style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
            2
          </div>
          <div>
            <strong class="text-dark">Menunggu Review</strong>
            <p class="text-muted mb-0">Bendahara akan mengecek dan memproses permohonan dana.</p>
          </div>
        </div>
        <div class="d-flex align-items-start gap-3">
          <div class="rounded-circle bg-success bg-opacity-10 p-2 flex-shrink-0 text-success fw-bold"
            style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
            3
          </div>
          <div>
            <strong class="text-dark">Dana Dicairkan</strong>
            <p class="text-muted mb-0">Setelah disetujui, dana tercatat dan transaksi siap dicairkan.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  function formatRupiahInput(input) {
    let value = input.value.replace(/[^0-9]/g, '');
    if (value) {
      input.value = new Intl.NumberFormat('id-ID').format(value);
    } else {
      input.value = '';
    }
  }

  document.getElementById('pengajuanForm').addEventListener('submit', function (e) {
    var btn = document.getElementById('submitBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Mengirim...';
  });
</script>

<?php require '../includes/footer.php'; ?>