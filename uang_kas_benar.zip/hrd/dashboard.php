<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'hrd') {
  header("Location: ../login.php");
  exit;
}

$uid = (int) $_SESSION['user_id'];

$counts = array('pending' => 0, 'disetujui' => 0, 'ditolak' => 0);
$qc = mysqli_query($conn, "SELECT status, COUNT(*) AS jumlah FROM pengajuan_dana WHERE hrd_id = $uid GROUP BY status");
if ($qc) {
  while ($row = mysqli_fetch_assoc($qc)) {
    $counts[$row['status']] = $row['jumlah'];
  }
}

$totalDiajukan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(jumlah), 0) AS total FROM pengajuan_dana WHERE hrd_id = $uid"))['total'];
$totalDisetujuiAmt = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(jumlah), 0) AS total FROM pengajuan_dana WHERE hrd_id = $uid AND status = 'disetujui'"))['total'];
$totalDitolakAmt = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(jumlah), 0) AS total FROM pengajuan_dana WHERE hrd_id = $uid AND status = 'ditolak'"))['total'];

$daftarTerbaru = array();
$qt = mysqli_query($conn, "SELECT * FROM pengajuan_dana WHERE hrd_id = $uid ORDER BY created_at DESC LIMIT 5");
if ($qt) {
  while ($row = mysqli_fetch_assoc($qt)) {
    $daftarTerbaru[] = $row;
  }
}

$pageTitle = 'Dashboard HRD';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(15px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .btn-hover-bounce {
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .card-modern {
    border: none;
    border-radius: 12px;
    background: #ffffff;
  }

  .card-stat {
    border: none;
    border-radius: 12px;
    position: relative;
    overflow: hidden;
    color: #fff;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  }

  .card-stat .stat-icon {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 2.2rem;
    opacity: 0.25;
  }

  .card-stat .stat-label {
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.9;
  }

  .card-stat .stat-value {
    font-size: 1.5rem;
    font-weight: 700;
    margin-top: 4px;
  }

  .bg-disetujui {
    background: linear-gradient(135deg, #2ecc71, #1abc9c);/
  }

  .bg-ditolak {
    background: linear-gradient(135deg, #ea4c46, #dc3545);
  }

  .bg-diajukan {
    background: linear-gradient(135deg, #46b5d1, #2980b9);
  }

  .bg-pending {
    background: linear-gradient(135deg, #ff7675, #ff6b6b);
  }

  .card-info-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 10px auto;
    font-size: 1.4rem;
  }

  .btn-primary {
    background-color: #3867d6;
    border-color: #3867d6;
  }

  .btn-primary:hover {
    background-color: #2b5797;
    border-color: #2b5797;
  }

  .table-light th {
    background-color: #f8f9fa;
    color: #8898aa;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold text-dark"><i class="bi bi-speedometer2 me-2 text-primary"></i> Dashboard HRD</h4>
  </div>
</div>

<div class="row g-3 mb-4 animate-fade-up">
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-disetujui p-3">
      <i class="bi bi-check-circle stat-icon"></i>
      <div class="stat-label">Disetujui</div>
      <div class="stat-value"><?= number_format($counts['disetujui'], 0, ',', '.') ?></div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-ditolak p-3">
      <i class="bi bi-x-circle stat-icon"></i>
      <div class="stat-label">Ditolak</div>
      <div class="stat-value"><?= number_format($counts['ditolak'], 0, ',', '.') ?></div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-diajukan p-3">
      <i class="bi bi-wallet2 stat-icon"></i>
      <div class="stat-label">Total Diajukan</div>
      <div class="stat-value">
        <?= function_exists('formatRupiah') ? formatRupiah($totalDiajukan) : 'Rp ' . number_format($totalDiajukan, 0, ',', '.') ?>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card card-stat bg-pending p-3">
      <i class="bi bi-hourglass-split stat-icon"></i>
      <div class="stat-label">Pending</div>
      <div class="stat-value"><?= number_format($counts['pending'], 0, ',', '.') ?></div>
    </div>
  </div>
</div>

<div class="row g-3 mb-4 animate-fade-up">
  <div class="col-md-4">
    <div class="card card-modern p-3 text-center shadow-sm">
      <div class="card-info-icon bg-success bg-opacity-10">
        <i class="bi bi-check-circle text-success"></i>
      </div>
      <h5 class="fw-bold mb-0 text-success">
        <?= function_exists('formatRupiah') ? formatRupiah($totalDisetujuiAmt) : 'Rp ' . number_format($totalDisetujuiAmt, 0, ',', '.') ?>
      </h5>
      <small class="text-muted">Total Dana Disetujui</small>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card card-modern p-3 text-center shadow-sm">
      <div class="card-info-icon bg-warning bg-opacity-10">
        <i class="bi bi-hourglass text-warning"></i>
      </div>
      <h5 class="fw-bold mb-0 text-warning"><?= number_format($counts['pending'], 0, ',', '.') ?> Pengajuan</h5>
      <small class="text-muted">Masih dalam Proses</small>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card card-modern p-3 text-center shadow-sm">
      <div class="card-info-icon bg-danger bg-opacity-10">
        <i class="bi bi-x-circle text-danger"></i>
      </div>
      <h5 class="fw-bold mb-0 text-danger">
        <?= function_exists('formatRupiah') ? formatRupiah($totalDitolakAmt) : 'Rp ' . number_format($totalDitolakAmt, 0, ',', '.') ?>
      </h5>
      <small class="text-muted">Total Dana Ditolak</small>
    </div>
  </div>
</div>

<div class="row g-3 animate-fade-up">
  <div class="col-lg-12">
    <div class="card card-modern p-4 shadow-sm">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold mb-0 text-dark">
          <i class="bi bi-clock-history text-primary me-2"></i> Pengajuan Terbaru
        </h6>
        <a href="pengajuan.php" class="btn btn-sm btn-outline-primary rounded-3 btn-hover-bounce">
          Lihat semua <i class="bi bi-arrow-right ms-1"></i>
        </a>
      </div>

      <div class="table-responsive">
        <table class="table table-hover table-bordered align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th>Tanggal</th>
              <th>Keperluan</th>
              <th class="text-end">Jumlah</th>
              <th class="text-center">Status</th>
            </tr>
          </thead>
            <?php if (empty($daftarTerbaru)): ?>
              <tr>
                <td colspan="4" class="text-center py-4">
                  <div class="empty-state">
                    <i class="bi bi-inbox fs-3 text-muted opacity-50 d-block mb-2"></i>
                    <p class="mb-2 text-muted small">Belum ada pengajuan. Klik tombol di bawah untuk membuat pengajuan
                      baru.</p>
                    <a href="pengajuan_form.php" class="btn btn-primary btn-sm rounded-3 btn-hover-bounce fw-semibold">
                      <i class="bi bi-plus-lg me-1"></i> Ajukan Dana
                    </a>
                  </div>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($daftarTerbaru as $p): ?>
                <tr>
                  <td class="text-muted small">
                    <i class="bi bi-calendar3 me-1"></i>
                    <?= function_exists('formatTanggalSingkat') ? formatTanggalSingkat($p['tanggal_pengajuan']) : date('d/m/Y', strtotime($p['tanggal_pengajuan'])) ?>
                  </td>
                  <td class="text-truncate fw-semibold text-dark" style="max-width: 280px;">
                    <?= htmlspecialchars($p['keperluan'], ENT_QUOTES, 'UTF-8') ?>
                  </td>
                  <td class="text-end fw-bold text-dark">
                    <?= function_exists('formatRupiah') ? formatRupiah($p['jumlah']) : 'Rp ' . number_format($p['jumlah'], 0, ',', '.') ?>
                  </td>
                  <td class="text-center">
                    <?php if (function_exists('badgeStatus')): ?>
                      <?= badgeStatus($p['status']) ?>
                    <?php else: ?>
                      <span class="badge bg-secondary"><?= htmlspecialchars($p['status'], ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require '../includes/footer.php'; ?>