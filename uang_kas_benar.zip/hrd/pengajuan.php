<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit;
}
if ($_SESSION['role'] != 'hrd') {
  header("Location: ../login.php");
  exit;
}

$uid = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
  $id = (int) $_POST['delete_id'];
  mysqli_query($conn, "DELETE FROM pengajuan_dana WHERE id = $id AND hrd_id = $uid AND status = 'pending'");
  if (mysqli_affected_rows($conn) > 0) {
    $_SESSION['flash'] = array('type' => 'success', 'message' => 'Pengajuan berhasil dibatalkan.');
  } else {
    $_SESSION['flash'] = array('type' => 'error', 'message' => 'Pengajuan tidak bisa dibatalkan (sudah diproses).');
  }
  header('Location: pengajuan.php');
  exit;
}

$status = isset($_GET['status']) ? $_GET['status'] : 'semua';
$allowedStatuses = array('semua', 'pending', 'disetujui', 'ditolak');
if (!in_array($status, $allowedStatuses)) {
  $status = 'semua';
}

$where = "WHERE hrd_id = $uid";
if ($status !== 'semua') {
  $statusEsc = mysqli_real_escape_string($conn, $status);
  $where .= " AND status = '$statusEsc'";
}

$daftar = array();
$q = mysqli_query($conn, "SELECT * FROM pengajuan_dana $where ORDER BY created_at DESC");
if ($q) {
  while ($row = mysqli_fetch_assoc($q)) {
    $daftar[] = $row;
  }
}

$counts = array('pending' => 0, 'disetujui' => 0, 'ditolak' => 0);
$qc = mysqli_query($conn, "SELECT status, COUNT(*) AS j FROM pengajuan_dana WHERE hrd_id = $uid GROUP BY status");
if ($qc) {
  while ($row = mysqli_fetch_assoc($qc)) {
    $counts[$row['status']] = $row['j'];
  }
}
$counts['semua'] = array_sum($counts);

$pageTitle = 'Pengajuan Dana';
require '../includes/header.php';
?>

<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(15px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-up {
    animation: fadeInUp 0.4s ease-out forwards;
  }

  .btn-hover-bounce {
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
  }

  .btn-hover-bounce:hover {
    transform: translateY(-2px);
  }

  .card-modern {
    border: none;
    border-radius: 14px;
    background: #ffffff;
  }

  .nav-pills-modern .nav-link {
    border-radius: 10px;
    color: #6c757d;
    font-weight: 500;
    padding: 8px 16px;
    transition: all 0.2s ease;
  }

  .nav-pills-modern .nav-link.active {
    background-color: #3867d6;
    color: #ffffff;
    box-shadow: 0 4px 10px rgba(56, 103, 214, 0.25);
  }

  .nav-pills-modern .nav-link .badge {
    transition: all 0.2s ease;
  }

  .nav-pills-modern .nav-link.active .badge {
    background-color: rgba(255, 255, 255, 0.2) !important;
    color: #ffffff !important;
  }

  .bg-soft-success {
    background-color: rgba(46, 204, 113, 0.12) !important;
    color: #2ecc71 !important;
  }

  .bg-soft-danger {
    background-color: rgba(231, 76, 60, 0.12) !important;
    color: #e74c3c !important;
  }

  .btn-primary {
    background-color: #3867d6;
    border-color: #3867d6;
  }

  .btn-primary:hover {
    background-color: #2b5797;
    border-color: #2b5797;
  }
</style>

<div class="page-header d-flex justify-content-between align-items-center mb-4 animate-fade-up">
  <div>
    <h4 class="mb-0 fw-bold"><i class="bi bi-file-earmark-text me-2 text-primary"></i>Daftar Pengajuan Dana</h4>
    <small class="text-muted">Kelola dan pantau status pengajuan dana operasional HRD</small>
  </div>
  <a href="pengajuan_form.php" class="btn btn-primary rounded-3 btn-hover-bounce fw-semibold px-3 shadow-sm">
    <i class="bi bi-plus-lg me-1"></i> Ajukan Dana Baru
  </a>
</div>

<ul class="nav nav-pills nav-pills-modern mb-3 animate-fade-up gap-1">
  <?php foreach (array('semua' => 'Semua', 'pending' => 'Menunggu', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak') as $key => $label): ?>
    <li class="nav-item">
      <a class="nav-link <?= $status === $key ? 'active' : '' ?>" href="?status=<?= $key ?>">
        <i
          class="bi bi-<?= $key === 'pending' ? 'clock' : ($key === 'disetujui' ? 'check-circle' : ($key === 'ditolak' ? 'x-circle' : 'list')) ?> me-1"></i>
        <?= $label ?>
        <span class="badge bg-light text-dark ms-1 rounded-pill"><?= number_format($counts[$key], 0, ',', '.') ?></span>
      </a>
    </li>
  <?php endforeach; ?>
</ul>

<div class="card card-modern p-3 shadow-sm animate-fade-up">
  <div class="table-responsive">
    <table class="table table-hover table-bordered align-middle mb-0">
      <thead class="table-light">
        <tr class="small text-muted">
          <th>Tanggal</th>
          <th>Keperluan</th>
          <th class="text-end">Jumlah</th>
          <th class="text-center">Status</th>
          <th>Catatan Bendahara</th>
          <th class="text-end">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($daftar)): ?>
          <tr>
            <td colspan="6" class="text-center py-4">
              <div class="empty-state">
                <i class="bi bi-inbox fs-3 text-muted opacity-50 d-block mb-2"></i>
                <h6 class="fw-bold text-muted mb-1">Belum Ada Pengajuan</h6>
                <p class="mb-2 text-muted small">Klik tombol di bawah untuk membuat pengajuan dana baru.</p>
                <a href="pengajuan_form.php" class="btn btn-primary btn-sm rounded-3 btn-hover-bounce fw-semibold">
                  <i class="bi bi-plus-lg me-1"></i> Ajukan Dana
                </a>
              </div>
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($daftar as $p): ?>
            <tr>
              <td class="text-muted small text-nowrap">
                <i class="bi bi-calendar3 me-1"></i>
                <?= function_exists('formatTanggal') ? formatTanggal($p['tanggal_pengajuan']) : date('d/m/Y', strtotime($p['tanggal_pengajuan'])) ?>
              </td>
              <td class="fw-semibold text-dark text-truncate" style="max-width: 250px;">
                <?= htmlspecialchars($p['keperluan'], ENT_QUOTES, 'UTF-8') ?>
              </td>
              <td class="text-end fw-bold text-dark text-nowrap">
                <?= function_exists('formatRupiah') ? formatRupiah($p['jumlah']) : 'Rp ' . number_format($p['jumlah'], 0, ',', '.') ?>
              </td>
              <td class="text-center">
                <?php if (function_exists('badgeStatus')): ?>
                  <?= badgeStatus($p['status']) ?>
                <?php else: ?>
                  <span class="badge bg-secondary"><?= htmlspecialchars($p['status'], ENT_QUOTES, 'UTF-8') ?></span>
                <?php endif; ?>
              </td>
              <td>
                <?php if (!empty($p['catatan_bendahara'])): ?>
                  <span class="small text-muted"
                    title="<?= htmlspecialchars($p['catatan_bendahara'], ENT_QUOTES, 'UTF-8') ?>">
                    <?= htmlspecialchars(mb_strimwidth($p['catatan_bendahara'], 0, 40, '...'), ENT_QUOTES, 'UTF-8') ?>
                  </span>
                <?php else: ?>
                  <span class="text-muted small">-</span>
                <?php endif; ?>
              </td>
              <td class="text-end text-nowrap">
                <?php if ($p['status'] === 'pending'): ?>
                  <form id="cancelForm<?= $p['id'] ?>" method="POST" style="display:inline;">
                    <input type="hidden" name="delete_id" value="<?= $p['id'] ?>">
                  </form>
                  <button type="button" class="btn btn-sm btn-outline-danger rounded-2 btn-hover-bounce"
                    data-confirm="Batalkan pengajuan ini?" data-confirm-form="cancelForm<?= $p['id'] ?>">
                    <i class="bi bi-x-circle me-1"></i> Batalkan
                  </button>
                <?php elseif ($p['status'] === 'disetujui'): ?>
                  <span class="badge bg-soft-success px-2 py-1"><i class="bi bi-check-circle me-1"></i> Selesai</span>
                <?php else: ?>
                  <span class="badge bg-soft-danger px-2 py-1"><i class="bi bi-x-circle me-1"></i> Ditolak</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require '../includes/footer.php'; ?>